/**
 * Mathematical models for lunar rotation, selenographic coordinates,
 * debris orbits, and rotational tumbling dynamics.
 */

export const LUNAR_LANDMARKS = [
  {
    id: 'copernicus',
    name: 'Copernicus Crater',
    selenographic: { latitudeDeg: 9.62, longitudeDeg: -20.08 },
    description: 'Prominent 93 km impact crater with multi-peaked central mountains rising 1.2 km above floor.',
    referenceImage: '/assets/aistudio/lunarorb_copernicus_000b6074.jpg',
    referenceCredit: 'NASA / Lunar Orbiter II (1966)',
    featureDescription: 'Central massifs, terraced inner ramparts, and extensive ray system.',
    idealSunAngleDeg: 72,
  },
  {
    id: 'tycho',
    name: 'Tycho Central Peak',
    selenographic: { latitudeDeg: -43.31, longitudeDeg: -11.36 },
    description: 'Iconic 85 km crater with jagged 2 km central mountain complex.',
    referenceImage: '/assets/aistudio/22_Tycho_Crater_terrestrial_14f590b0.png',
    referenceCredit: 'NASA LRO / Terrestrial Telescopic',
    featureDescription: 'Steep striated rock massifs and prominent ejecta rays spanning thousands of kilometers.',
    idealSunAngleDeg: 80,
  },
  {
    id: 'komarov',
    name: 'Komarov Tectonic Rilles',
    selenographic: { latitudeDeg: 24.55, longitudeDeg: 151.75 },
    description: 'Fractured-floor impact crater dissected by deep graben and fault valleys.',
    referenceImage: '/assets/aistudio/Komarov_084d36f7.png',
    referenceCredit: 'NASA / Lunar Reconnaissance Orbiter (LROC)',
    featureDescription: 'Sunken fault-bounded crustal blocks and tectonic rift valleys.',
    idealSunAngleDeg: 110,
  },
  {
    id: 'malapert',
    name: 'Malapert Massif & South Pole',
    selenographic: { latitudeDeg: -84.9, longitudeDeg: 12.9 },
    description: 'Towering 5 km mountain massif near the lunar south pole with grazing low-sun shadows.',
    referenceImage: '/assets/aistudio/MalapertMassif-1_63d94d37.png',
    referenceCredit: 'NASA / Intuitive Machines / LROC',
    featureDescription: 'Extreme low-angle solar relief, deep permanently shadowed crater bowls.',
    idealSunAngleDeg: 90,
  },
  {
    id: 'plato',
    name: 'Plato & Sinuous Lava Rille',
    selenographic: { latitudeDeg: 51.62, longitudeDeg: -9.38 },
    description: 'Dark basaltic lava-filled crater with sinuous rille channels carved by ancient lava flows.',
    referenceImage: '/assets/aistudio/plato_152a6d98.jpg',
    referenceCredit: 'NASA / LROC Narrow Angle Camera',
    featureDescription: 'Meandering volcanic lava channels, sharp basalt cliffs, micro-cratering.',
    idealSunAngleDeg: 65,
  },
  {
    id: 'earthrise',
    name: 'Limb Horizon & Earthrise',
    selenographic: { latitudeDeg: -15.0, longitudeDeg: 95.0 },
    description: 'Jagged 3D crater crenellations on the lunar limb silhouette with Earth rising in the background.',
    referenceImage: '/assets/aistudio/art002e009287_large_68a78c5e.jpg',
    referenceCredit: 'NASA / Artemis I Orion Spacecraft',
    featureDescription: 'Physical 3D elevation profile showing crater rim crenellations along the horizon.',
    idealSunAngleDeg: 135,
  },
];

/**
 * Real Moon's sidereal rotation period is ~27.321661 days (~655.7 hours).
 * For simulation, a default base period in seconds (e.g. 120s for graceful contemplative drift).
 */
export const LUNAR_AXIAL_TILT_RAD = (1.5424 * Math.PI) / 180; // 1.54° axial tilt relative to ecliptic

/**
 * Calculates the current lunar rotation angle around its polar axis in radians.
 */
export function calculateAxialRotation(
  elapsedSeconds,
  speedMultiplier = 1.0,
  basePeriodSeconds = 120
) {
  if (basePeriodSeconds <= 0) return 0;
  const angularVelocity = (2 * Math.PI) / basePeriodSeconds;
  return (elapsedSeconds * speedMultiplier * angularVelocity) % (2 * Math.PI);
}

/**
 * Calculate the sub-solar point in selenographic coordinates (lon, lat in degrees)
 * from the sun's direction vector relative to the Moon's rotation.
 */
export function calculateSubsolarPoint(sunAngleRad, moonRotationRad) {
  const relAngle = sunAngleRad - moonRotationRad;
  let lonDeg = (relAngle * 180) / Math.PI;
  lonDeg = ((lonDeg + 180) % 360) - 180;
  if (lonDeg < -180) lonDeg += 360;

  const latDeg = (LUNAR_AXIAL_TILT_RAD * 180 / Math.PI) * Math.sin(sunAngleRad);

  return {
    longitudeDeg: Number(lonDeg.toFixed(2)),
    latitudeDeg: Number(latDeg.toFixed(2)),
  };
}

/**
 * Converts selenographic latitude & longitude (degrees) to 3D Cartesian coordinates on a sphere of radius R.
 */
export function selenographicToCartesian(latDeg, lonDeg, radius = 3.0) {
  const latRad = (latDeg * Math.PI) / 180;
  const lonRad = (lonDeg * Math.PI) / 180;

  // In our coordinate space: Y is polar axis, X & Z are equatorial plane
  const y = radius * Math.sin(latRad);
  const cosLat = Math.cos(latRad);
  const x = radius * cosLat * Math.sin(lonRad);
  const z = radius * cosLat * Math.cos(lonRad);

  return { x, y, z };
}

/**
 * Computes lunar phase appearance based on angle between Sun vector and Observer vector.
 */
export function calculateLunarPhase(sunAngleRad, observerAngleRad) {
  let angle = Math.abs(sunAngleRad - observerAngleRad) % (2 * Math.PI);
  if (angle > Math.PI) {
    angle = 2 * Math.PI - angle;
  }

  const phaseAngleDeg = (angle * 180) / Math.PI;
  const illuminationFraction = (1 + Math.cos(angle)) / 2;

  let phaseName = 'Full Moon';
  if (illuminationFraction < 0.03) {
    phaseName = 'New Moon';
  } else if (illuminationFraction < 0.47) {
    phaseName = (sunAngleRad - observerAngleRad > 0) ? 'Waxing Crescent' : 'Waning Crescent';
  } else if (illuminationFraction <= 0.53) {
    phaseName = (sunAngleRad - observerAngleRad > 0) ? 'First Quarter' : 'Last Quarter';
  } else if (illuminationFraction < 0.97) {
    phaseName = (sunAngleRad - observerAngleRad > 0) ? 'Waxing Gibbous' : 'Waning Gibbous';
  }

  return {
    phaseName,
    illuminationFraction: Number(illuminationFraction.toFixed(3)),
    phaseAngleDeg: Number(phaseAngleDeg.toFixed(1)),
  };
}

/**
 * Calculates 3D orbital position from simplified Keplerian orbital elements at time t.
 */
export function calculateOrbitalPosition(orbit, timeSeconds) {
  const M = orbit.meanMotion * timeSeconds;
  const E = M + orbit.eccentricity * Math.sin(M);

  const v = 2 * Math.atan2(
    Math.sqrt(1 + orbit.eccentricity) * Math.sin(E / 2),
    Math.sqrt(1 - orbit.eccentricity) * Math.cos(E / 2)
  );

  const r = orbit.semiMajorAxis * (1 - orbit.eccentricity * Math.cos(E));

  const u = v + orbit.argumentOfPeriapsisRad;
  const xOrb = r * Math.cos(u);
  const yOrb = r * Math.sin(u);

  const cosNode = Math.cos(orbit.longitudeOfAscendingNodeRad);
  const sinNode = Math.sin(orbit.longitudeOfAscendingNodeRad);
  const cosInc = Math.cos(orbit.inclinationRad);
  const sinInc = Math.sin(orbit.inclinationRad);

  const x = xOrb * cosNode - yOrb * sinNode * cosInc;
  const y = yOrb * sinInc;
  const z = xOrb * sinNode + yOrb * cosNode * cosInc;

  return { x, y, z };
}

/**
 * Tumbles a space rock across 3 axes based on its chaotic angular velocity vector.
 */
export function calculateTumble(currentRot, angularVelocity, dt) {
  const TWO_PI = Math.PI * 2;
  return {
    x: (currentRot.x + angularVelocity.x * dt) % TWO_PI,
    y: (currentRot.y + angularVelocity.y * dt) % TWO_PI,
    z: (currentRot.z + angularVelocity.z * dt) % TWO_PI,
  };
}

/**
 * Formats time or period for telemetry display.
 */
export function formatTelemetryTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  const millis = Math.floor((seconds % 1) * 100);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${String(millis).padStart(2, '0')}`;
}
