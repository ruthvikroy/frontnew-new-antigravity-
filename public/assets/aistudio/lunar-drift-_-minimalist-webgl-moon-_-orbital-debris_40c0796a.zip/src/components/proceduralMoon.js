import * as THREE from 'three';

/**
 * Photorealistic Lunar Texture Pipeline for WebGL.
 * Combines real NASA reconnaissance imagery:
 * - PIA13998: LRO high-density crater field
 * - plato: LRO volcanic mare & sinuous rilles
 * - Komarov: LROC fractured-floor graben & faults
 * - MalapertMassif: Polar mountain massifs & low-sun shadows
 * - 22_Tycho_Crater_terrestrial: Tycho central mountain peak
 * - lunarorb_copernicus: Copernicus multi-tier terraces & massifs
 * - art002e009287_large: Artemis Orion lunar limb photography
 * 
 * Generates:
 * 1. Albedo / Diffuse map with genuine lunar reflectance
 * 2. 3D Displacement / Elevation map
 * 3. Tangent-Space Sobel Normal map for razor-sharp crater lighting
 * 4. Micro-regolith Roughness map
 */

// Prominent lunar maria (dark volcanic basaltic plains)
const MARIA_REGIONS = [
  { name: 'Oceanus Procellarum', u: 0.35, v: 0.45, rx: 0.17, ry: 0.19, darkness: 0.68 },
  { name: 'Mare Imbrium', u: 0.45, v: 0.36, rx: 0.12, ry: 0.10, darkness: 0.72 },
  { name: 'Mare Serenitatis', u: 0.55, v: 0.40, rx: 0.09, ry: 0.08, darkness: 0.74 },
  { name: 'Mare Tranquillitatis', u: 0.58, v: 0.47, rx: 0.10, ry: 0.09, darkness: 0.76 },
  { name: 'Mare Crisium', u: 0.66, v: 0.42, rx: 0.055, ry: 0.048, darkness: 0.77 },
  { name: 'Mare Fecunditatis', u: 0.64, v: 0.54, rx: 0.075, ry: 0.075, darkness: 0.71 },
  { name: 'Mare Nectaris', u: 0.59, v: 0.57, rx: 0.055, ry: 0.055, darkness: 0.70 },
  { name: 'Mare Nubium', u: 0.45, v: 0.57, rx: 0.075, ry: 0.075, darkness: 0.70 },
  { name: 'Mare Humorum', u: 0.38, v: 0.58, rx: 0.048, ry: 0.048, darkness: 0.74 },
];

const PHOTO_STAMPS = [
  // Copernicus Crater (NASA Lunar Orbiter II)
  {
    url: '/assets/aistudio/lunarorb_copernicus_000b6074.jpg',
    u: 0.444,
    v: 0.446,
    scaleU: 0.048,
    scaleV: 0.038,
    blendMode: 'source-over',
    opacity: 0.88,
    elevationWeight: 1.2,
  },
  // Tycho Central Mountain Peak (NASA / Telescopic)
  {
    url: '/assets/aistudio/22_Tycho_Crater_terrestrial_14f590b0.png',
    u: 0.468,
    v: 0.74,
    scaleU: 0.045,
    scaleV: 0.042,
    blendMode: 'source-over',
    opacity: 0.9,
    elevationWeight: 1.4,
  },
  // Komarov Fractured Graben (NASA LROC)
  {
    url: '/assets/aistudio/Komarov_084d36f7.png',
    u: 0.92,
    v: 0.364,
    scaleU: 0.042,
    scaleV: 0.042,
    blendMode: 'source-over',
    opacity: 0.85,
    elevationWeight: 1.1,
  },
  // Malapert Massif South Pole (Intuitive Machines / LROC)
  {
    url: '/assets/aistudio/MalapertMassif-1_63d94d37.png',
    u: 0.535,
    v: 0.965,
    scaleU: 0.052,
    scaleV: 0.035,
    blendMode: 'source-over',
    opacity: 0.88,
    elevationWeight: 1.5,
  },
  // Plato Crater & Sinuous Lava Rille (NASA LROC)
  {
    url: '/assets/aistudio/plato_152a6d98.jpg',
    u: 0.474,
    v: 0.213,
    scaleU: 0.044,
    scaleV: 0.044,
    blendMode: 'source-over',
    opacity: 0.85,
    elevationWeight: 1.0,
  },
];

function loadImage(src) {
  return new Promise(resolve => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => {
      console.warn('Could not load texture asset:', src);
      resolve(null);
    };
    img.src = src;
  });
}

/**
 * Computes Tangent-Space Sobel Normal Map from a grayscale height/displacement canvas
 */
function computeSobelNormalMap(
  heightCtx,
  width,
  height,
  strength = 3.2
) {
  const src = heightCtx.getImageData(0, 0, width, height);
  const srcData = src.data;
  const normalImg = heightCtx.createImageData(width, height);
  const normData = normalImg.data;

  // Helper to read height (0..1)
  const hAt = (px, py) => {
    const x = ((px % width) + width) % width;
    const y = Math.max(0, Math.min(height - 1, py));
    return srcData[(y * width + x) * 4] / 255.0;
  };

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      // 3x3 Sobel kernel
      const tl = hAt(x - 1, y - 1);
      const t = hAt(x, y - 1);
      const tr = hAt(x + 1, y - 1);
      const l = hAt(x - 1, y);
      const r = hAt(x + 1, y);
      const bl = hAt(x - 1, y + 1);
      const b = hAt(x, y + 1);
      const br = hAt(x + 1, y + 1);

      // Horizontal and vertical gradients
      const dx = (tr + 2 * r + br) - (tl + 2 * l + bl);
      const dy = (bl + 2 * b + br) - (tl + 2 * t + tr);
      const dz = 1.0 / strength;

      // Normalize vector (-1..1 to 0..255)
      const len = Math.hypot(dx, dy, dz);
      const nx = -dx / len;
      const ny = -dy / len;
      const nz = dz / len;

      const idx = (y * width + x) * 4;
      normData[idx] = Math.floor((nx * 0.5 + 0.5) * 255);
      normData[idx + 1] = Math.floor((ny * 0.5 + 0.5) * 255);
      normData[idx + 2] = Math.floor((nz * 0.5 + 0.5) * 255);
      normData[idx + 3] = 255;
    }
  }

  return normalImg;
}

export function createPhotorealisticMoonTextures(
  isSoftwareGl = false,
  onTexturesUpdated
) {
  const width = isSoftwareGl ? 1024 : 2048;
  const height = isSoftwareGl ? 512 : 1024;

  // Canvases
  const diffuseCanvas = document.createElement('canvas');
  diffuseCanvas.width = width;
  diffuseCanvas.height = height;
  const diffuseCtx = diffuseCanvas.getContext('2d');

  const dispCanvas = document.createElement('canvas');
  dispCanvas.width = width;
  dispCanvas.height = height;
  const dispCtx = dispCanvas.getContext('2d');

  const normalCanvas = document.createElement('canvas');
  normalCanvas.width = width;
  normalCanvas.height = height;
  const normalCtx = normalCanvas.getContext('2d');

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = width;
  bumpCanvas.height = height;
  const bumpCtx = bumpCanvas.getContext('2d');

  const roughnessCanvas = document.createElement('canvas');
  roughnessCanvas.width = width;
  roughnessCanvas.height = height;
  const roughnessCtx = roughnessCanvas.getContext('2d');

  // 1. Initial High-Quality Procedural Base (renders synchronously so scene displays immediately)
  paintBaseLunarSurface(diffuseCtx, dispCtx, bumpCtx, roughnessCtx, width, height);

  // Compute initial normal map
  const initialNormals = computeSobelNormalMap(dispCtx, width, height, 2.8);
  normalCtx.putImageData(initialNormals, 0, 0);

  const diffuseMap = new THREE.CanvasTexture(diffuseCanvas);
  diffuseMap.colorSpace = THREE.SRGBColorSpace;
  diffuseMap.wrapS = THREE.RepeatWrapping;
  diffuseMap.wrapT = THREE.ClampToEdgeWrapping;

  const displacementMap = new THREE.CanvasTexture(dispCanvas);
  displacementMap.wrapS = THREE.RepeatWrapping;
  displacementMap.wrapT = THREE.ClampToEdgeWrapping;

  const normalMap = new THREE.CanvasTexture(normalCanvas);
  normalMap.wrapS = THREE.RepeatWrapping;
  normalMap.wrapT = THREE.ClampToEdgeWrapping;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.ClampToEdgeWrapping;

  const roughnessMap = new THREE.CanvasTexture(roughnessCanvas);
  roughnessMap.wrapS = THREE.RepeatWrapping;
  roughnessMap.wrapT = THREE.ClampToEdgeWrapping;

  const result = {
    diffuseMap,
    displacementMap,
    normalMap,
    bumpMap,
    roughnessMap,
    isReady: false,
  };

  // 2. Load Real NASA Photographic Assets Asynchronously and Composite them
  Promise.all([
    loadImage('/assets/aistudio/plato_152a6d98.jpg'),
    loadImage('/assets/aistudio/art002e009287_large_68a78c5e.jpg'),
    ...PHOTO_STAMPS.map(stamp => loadImage(stamp.url)),
  ]).then(([regolithImg, artemisImg, ...stampImgs]) => {
    // A. Blend real photographic crater textures across the globe seamlessly
    if (regolithImg) {
      const patternCanvas = document.createElement('canvas');
      patternCanvas.width = width;
      patternCanvas.height = height;
      const pCtx = patternCanvas.getContext('2d');

      // Mirrored horizontal wrap for 100% seamless spherical equirectangular mapping
      pCtx.drawImage(regolithImg, 0, 0, width / 2, height);
      pCtx.save();
      pCtx.translate(width, 0);
      pCtx.scale(-1, 1);
      pCtx.drawImage(regolithImg, 0, 0, width / 2, height);
      pCtx.restore();

      // Soft natural blend over diffuse canvas
      diffuseCtx.globalAlpha = 0.38;
      diffuseCtx.globalCompositeOperation = 'overlay';
      diffuseCtx.drawImage(patternCanvas, 0, 0);

      // Soft natural blend onto displacement canvas
      dispCtx.globalAlpha = 0.35;
      dispCtx.globalCompositeOperation = 'overlay';
      dispCtx.drawImage(patternCanvas, 0, 0);
    }

    // B. Blend real Artemis photo details into dark maria regions with soft feathered gradients
    if (artemisImg) {
      const mareCanvas = document.createElement('canvas');
      mareCanvas.width = width;
      mareCanvas.height = height;
      const mCtx = mareCanvas.getContext('2d');

      // Draw real basalt lava photos in maria locations with soft radial falloff
      for (const mare of MARIA_REGIONS) {
        const mx = mare.u * width;
        const my = mare.v * height;
        const mrx = mare.rx * width * 1.4;
        const mry = mare.ry * height * 1.4;

        mCtx.save();
        mCtx.beginPath();
        mCtx.ellipse(mx, my, mrx, mry, 0, 0, Math.PI * 2);

        // Soft radial feathering
        const grad = mCtx.createRadialGradient(mx, my, mrx * 0.2, mx, my, mrx);
        grad.addColorStop(0, 'rgba(255,255,255,1.0)');
        grad.addColorStop(0.7, 'rgba(255,255,255,0.6)');
        grad.addColorStop(1, 'rgba(255,255,255,0.0)');

        mCtx.clip();
        mCtx.drawImage(artemisImg, mx - mrx, my - mry, mrx * 2, mry * 2);
        mCtx.globalCompositeOperation = 'destination-in';
        mCtx.fillStyle = grad;
        mCtx.fill();
        mCtx.restore();
      }

      diffuseCtx.globalAlpha = 0.35;
      diffuseCtx.globalCompositeOperation = 'multiply';
      diffuseCtx.drawImage(mareCanvas, 0, 0);
    }

    // C. Stamp reference images at landmark coordinates with ultra-soft feathered radial edges
    for (let i = 0; i < PHOTO_STAMPS.length; i++) {
      const stamp = PHOTO_STAMPS[i];
      const img = stampImgs[i];
      if (!img) continue;

      const cx = stamp.u * width;
      const cy = stamp.v * height;
      const w = stamp.scaleU * width;
      const h = stamp.scaleV * height;

      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = w * 2;
      tempCanvas.height = h * 2;
      const tCtx = tempCanvas.getContext('2d');

      tCtx.drawImage(img, 0, 0, w * 2, h * 2);

      // Deep multi-stop radial feathering so there are zero visible square borders
      tCtx.globalCompositeOperation = 'destination-in';
      const grad = tCtx.createRadialGradient(w, h, Math.min(w, h) * 0.15, w, h, Math.min(w, h) * 0.95);
      grad.addColorStop(0, 'rgba(0,0,0,0.85)');
      grad.addColorStop(0.5, 'rgba(0,0,0,0.45)');
      grad.addColorStop(0.85, 'rgba(0,0,0,0.15)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');
      tCtx.fillStyle = grad;
      tCtx.fillRect(0, 0, w * 2, h * 2);

      // Draw smoothly onto diffuse canvas
      diffuseCtx.globalAlpha = 0.55;
      diffuseCtx.globalCompositeOperation = 'source-over';
      diffuseCtx.drawImage(tempCanvas, cx - w, cy - h);

      // Draw smoothly onto displacement canvas
      dispCtx.globalAlpha = 0.45;
      dispCtx.globalCompositeOperation = 'source-over';
      dispCtx.drawImage(tempCanvas, cx - w, cy - h);
    }

    // Reset canvas composite operations
    diffuseCtx.globalAlpha = 1.0;
    diffuseCtx.globalCompositeOperation = 'source-over';
    dispCtx.globalAlpha = 1.0;
    dispCtx.globalCompositeOperation = 'source-over';

    // D. Recompute high-definition Sobel normal map from the photographic displacement
    const hdNormals = computeSobelNormalMap(dispCtx, width, height, 3.4);
    normalCtx.putImageData(hdNormals, 0, 0);

    // E. Update Three.js textures
    diffuseMap.needsUpdate = true;
    displacementMap.needsUpdate = true;
    normalMap.needsUpdate = true;
    bumpMap.needsUpdate = true;
    roughnessMap.needsUpdate = true;
    result.isReady = true;

    if (onTexturesUpdated) {
      onTexturesUpdated();
    }
  });

  return result;
}

/**
 * Procedural baseline lunar surface rendering (highland craters, maria, ejecta rays)
 */
function paintBaseLunarSurface(
  dCtx,
  dispCtx,
  bCtx,
  rCtx,
  width,
  height
) {
  const dImg = dCtx.createImageData(width, height);
  const dispImg = dispCtx.createImageData(width, height);
  const bImg = bCtx.createImageData(width, height);
  const rImg = rCtx.createImageData(width, height);

  const d = dImg.data;
  const dp = dispImg.data;
  const b = bImg.data;
  const r = rImg.data;

  // Pre-generate crater seed array
  const craters = [];
  for (let i = 0; i < 480; i++) {
    const cu = (Math.sin(i * 12.9898) * 43758.5453) % 1;
    const cv = 0.05 + Math.abs((Math.sin(i * 78.233) * 43758.5453) % 0.9);
    const cr = 0.003 + Math.pow(Math.abs((Math.sin(i * 37.719) * 43758.5453) % 1), 3.2) * 0.035;
    const cd = 0.3 + Math.abs((Math.sin(i * 91.137) * 43758.5453) % 0.7);
    craters.push({ u: cu < 0 ? cu + 1 : cu, v: cv, r: cr, d: cd });
  }

  for (let y = 0; y < height; y++) {
    const v = y / height;
    const phi = (v - 0.5) * Math.PI;
    const cosPhi = Math.max(0.12, Math.cos(phi));

    for (let x = 0; x < width; x++) {
      const u = x / width;
      const idx = (y * width + x) * 4;

      // Highland base topography
      const n1 = Math.sin(u * 28 + v * 14) * 0.5 + 0.5;
      const n2 = Math.cos(u * 56 - v * 28) * 0.5 + 0.5;
      const regolithNoise = ((Math.sin(u * 900 + y * 900) * 43758.5453) % 1) * 8;

      let albedo = 118 + (n1 * 0.6 + n2 * 0.4 - 0.5) * 36 + regolithNoise;
      let elev = 128 + (n1 - 0.5) * 38;
      let rough = 230;

      // Maria dark volcanic plains
      for (const mare of MARIA_REGIONS) {
        const du = Math.abs(u - mare.u);
        const distU = Math.min(du, 1 - du) * cosPhi;
        const distV = Math.abs(v - mare.v);
        const normDist = Math.hypot(distU / mare.rx, distV / mare.ry);

        if (normDist < 1.0) {
          const t = 1.0 - normDist;
          const falloff = t * t * (3 - 2 * t);
          albedo -= falloff * 64;
          elev -= falloff * 28;
          rough -= Math.floor(falloff * 40);
        }
      }

      // Major crater Tycho & Copernicus rays
      // Tycho at u=0.468, v=0.74
      const tdu = Math.min(Math.abs(u - 0.468), 1 - Math.abs(u - 0.468)) * cosPhi;
      const tdv = Math.abs(v - 0.74);
      const tDist = Math.hypot(tdu, tdv);
      if (tDist > 0.02 && tDist < 0.65) {
        const angle = Math.atan2(tdv, tdu);
        const ray = Math.sin(angle * 24);
        if (ray > 0.55) {
          const rayIntensity = ((ray - 0.55) / 0.45) * (1 - tDist / 0.65) * 58;
          albedo += rayIntensity;
        }
      }

      // Small & medium crater bowls
      for (let i = 0; i < craters.length; i++) {
        const c = craters[i];
        const cu = Math.min(Math.abs(u - c.u), 1 - Math.abs(u - c.u)) * cosPhi;
        const cv = Math.abs(v - c.v);
        const dist = Math.hypot(cu, cv);

        if (dist < c.r * 1.5) {
          const ratio = dist / c.r;
          if (ratio < 0.88) {
            elev -= (1 - ratio / 0.88) * 35 * c.d;
            albedo -= (1 - ratio / 0.88) * 14 * c.d;
          } else if (ratio < 1.35) {
            const rim = (1 - Math.abs(ratio - 1.0) / 0.35) * 26 * c.d;
            elev += rim;
            albedo += rim * 0.95;
          }
        }
      }

      const finalAlb = Math.max(30, Math.min(245, Math.floor(albedo)));
      const finalElev = Math.max(0, Math.min(255, Math.floor(elev)));
      const finalRough = Math.max(140, Math.min(255, Math.floor(rough)));

      d[idx] = finalAlb;
      d[idx + 1] = Math.floor(finalAlb * 0.985);
      d[idx + 2] = Math.floor(finalAlb * 0.97);
      d[idx + 3] = 255;

      dp[idx] = finalElev;
      dp[idx + 1] = finalElev;
      dp[idx + 2] = finalElev;
      dp[idx + 3] = 255;

      b[idx] = finalElev;
      b[idx + 1] = finalElev;
      b[idx + 2] = finalElev;
      b[idx + 3] = 255;

      r[idx] = finalRough;
      r[idx + 1] = finalRough;
      r[idx + 2] = finalRough;
      r[idx + 3] = 255;
    }
  }

  dCtx.putImageData(dImg, 0, 0);
  dispCtx.putImageData(dispImg, 0, 0);
  bCtx.putImageData(bImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);
}

/**
 * Procedural starfield background geometry
 */
export function createStarfieldBackground() {
  const count = 1800;
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  const sizes = new Float32Array(count);

  const colorPalette = [
    new THREE.Color(0xffffff),
    new THREE.Color(0xdde8ff),
    new THREE.Color(0xfff4e8),
    new THREE.Color(0xffeedd),
    new THREE.Color(0x99bbff),
  ];

  for (let i = 0; i < count; i++) {
    const i3 = i * 3;
    const radius = 350 + Math.random() * 120;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);

    positions[i3] = radius * Math.sin(phi) * Math.cos(theta);
    positions[i3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
    positions[i3 + 2] = radius * Math.cos(phi);

    const c = colorPalette[Math.floor(Math.random() * colorPalette.length)];
    const brightness = 0.5 + Math.random() * 0.5;
    colors[i3] = c.r * brightness;
    colors[i3 + 1] = c.g * brightness;
    colors[i3 + 2] = c.b * brightness;

    sizes[i] = 1.0 + Math.random() * 2.2;
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

  return geometry;
}
