import React, { useState } from 'react';
import {
  Play,
  Pause,
  Sun,
  Volume2,
  VolumeX,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Compass,
  Camera,
  Eye,
  Mountain,
  Image as ImageIcon,
  X,
  Cloud,
} from 'lucide-react';
import { LUNAR_LANDMARKS } from '../utils/orbitalMath.js';

export const MinimalHUD = ({
  telemetry,
  speedMultiplier,
  setSpeedMultiplier,
  isPaused,
  setIsPaused,
  reliefScale,
  setReliefScale,
  showAxes,
  setShowAxes,
  showLandingSites,
  setShowLandingSites,
  cameraPreset,
  setCameraPreset,
  selectedLandmarkId,
  setSelectedLandmarkId,
  sunPhaseAngle,
  setSunPhaseAngle,
  isAudioActive,
  onToggleAudio,
  isZenMode,
  setIsZenMode,
  onOpenDrive,
}) => {
  const [activeTab, setActiveTab] = useState('relief');
  const [showReferenceCard, setShowReferenceCard] = useState(true);

  const activeLandmark = LUNAR_LANDMARKS.find(
    l => l.id === selectedLandmarkId
  );

  return (
    <>
      {/* 1. Top Right Quick Actions (Google Drive, Audio, & Zen toggle) */}
      <div className="fixed top-4 right-5 z-20 flex items-center gap-2">
        <button
          onClick={onOpenDrive}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-cyan-500/35 bg-[#080d14]/90 text-xs font-mono text-cyan-200 hover:bg-cyan-950/60 hover:border-cyan-400 transition-colors"
          aria-label="Open Google Drive Archive"
          title="Save snapshots and presets to Google Drive"
        >
          <Cloud size={14} className="text-cyan-400" />
          <span className="hidden sm:inline">Google Drive</span>
        </button>

        <button
          onClick={onToggleAudio}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono transition-colors ${
            isAudioActive
              ? 'bg-cyan-950/60 border-cyan-500/40 text-cyan-300'
              : 'bg-[#080d14]/85 border-white/10 text-zinc-400 hover:text-zinc-200'
          }`}
          aria-label={isAudioActive ? 'Mute ambient space resonance' : 'Unmute ambient space resonance'}
          title="Procedural Cosmic Resonance"
        >
          {isAudioActive ? <Volume2 size={14} /> : <VolumeX size={14} />}
          <span className="hidden sm:inline">{isAudioActive ? 'Audio ON' : 'Audio OFF'}</span>
        </button>

        <button
          onClick={() => setIsZenMode(!isZenMode)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 bg-[#080d14]/85 text-xs font-mono text-zinc-300 hover:text-white transition-colors"
          aria-label={isZenMode ? 'Show control dock' : 'Enter Zen Cinema mode'}
          title="Toggle Zen Mode (H)"
        >
          <Eye size={14} />
          <span className="hidden sm:inline">{isZenMode ? 'Show HUD' : 'Zen Mode'}</span>
        </button>
      </div>

      {/* 2. Floating Reference Photo Card (Appears when a specific reference landmark is chosen) */}
      {activeLandmark && showReferenceCard && !isZenMode && (
        <aside
          aria-label="NASA Reconnaissance Reference Photo"
          className="fixed top-20 right-5 z-20 w-80 bg-[#080d14]/90 border border-white/15 rounded-xl shadow-2xl p-3 font-mono text-xs select-none transition-all animate-in fade-in slide-in-from-right-4 duration-300"
        >
          <div className="flex items-center justify-between border-b border-white/10 pb-2 mb-2">
            <div className="flex items-center gap-1.5 text-amber-300 font-semibold">
              <ImageIcon size={14} />
              <span>REFERENCE PHOTO</span>
            </div>
            <button
              onClick={() => setShowReferenceCard(false)}
              className="text-zinc-400 hover:text-white p-0.5 rounded transition-colors"
              aria-label="Close reference image card"
            >
              <X size={14} />
            </button>
          </div>

          <div className="relative rounded-lg overflow-hidden border border-white/10 bg-black aspect-[4/3] mb-2 group">
            <img
              src={activeLandmark.referenceImage}
              alt={activeLandmark.name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
            <span className="absolute bottom-1.5 left-2 text-[10px] text-zinc-300 font-mono drop-shadow">
              {activeLandmark.referenceCredit}
            </span>
          </div>

          <div className="space-y-1 text-[11px]">
            <h4 className="text-zinc-100 font-semibold">{activeLandmark.name}</h4>
            <p className="text-zinc-400 leading-tight text-[10px]">
              {activeLandmark.description}
            </p>
            <div className="text-[10px] text-cyan-300/90 pt-1 border-t border-white/5">
              3D Feature: {activeLandmark.featureDescription}
            </div>
          </div>
        </aside>
      )}

      {/* 3. Unified Bottom Control Dock */}
      <nav
        aria-label="Simulation Controls Dock"
        style={{
          bottom: '20px',
          left: '50%',
          transform: isZenMode ? 'translate(-50%, 130%)' : 'translate(-50%, 0)',
          maxWidth: 'min(940px, 94vw)',
        }}
        className="fixed z-20 w-full transition-transform duration-500 ease-out select-none"
      >
        <div className="relative mx-auto bg-[#080d14]/92 border border-white/12 rounded-xl shadow-2xl p-3 sm:p-4 text-zinc-200">
          {/* Collapse handle button on top edge of dock */}
          <button
            onClick={() => setIsZenMode(true)}
            className="absolute -top-7 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-t-md bg-[#080d14]/92 border-t border-x border-white/10 text-[11px] font-mono text-zinc-400 hover:text-zinc-200 flex items-center gap-1 transition-colors"
            aria-label="Hide controls dock"
          >
            <ChevronDown size={13} />
            <span>Hide Dock</span>
          </button>

          {/* Navigation Category Tabs */}
          <div className="flex items-center justify-between border-b border-white/10 pb-2.5 mb-3 gap-2 overflow-x-auto text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setActiveTab('relief')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
                  activeTab === 'relief'
                    ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 font-medium'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/5'
                }`}
              >
                <Mountain size={13} />
                <span>3D Textures &amp; Landmarks</span>
              </button>

              <button
                onClick={() => setActiveTab('sun')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
                  activeTab === 'sun'
                    ? 'bg-white/15 text-white font-medium shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/5'
                }`}
              >
                <Sun size={13} />
                <span>Solar Phase</span>
              </button>

              <button
                onClick={() => setActiveTab('camera')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
                  activeTab === 'camera'
                    ? 'bg-white/15 text-white font-medium shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/5'
                }`}
              >
                <Camera size={13} />
                <span>Camera Views</span>
              </button>

              <button
                onClick={() => setActiveTab('orbit')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
                  activeTab === 'orbit'
                    ? 'bg-white/15 text-white font-medium shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-white/5'
                }`}
              >
                <Compass size={13} />
                <span>Rotation &amp; Drift</span>
              </button>
            </div>

            {/* Quick Play/Pause on right */}
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-zinc-800 hover:bg-zinc-700 text-zinc-100 transition-colors shrink-0"
              aria-label={isPaused ? 'Resume lunar rotation' : 'Pause lunar rotation'}
            >
              {isPaused ? <Play size={12} /> : <Pause size={12} />}
              <span>{isPaused ? 'Resume' : 'Pause'}</span>
            </button>
          </div>

          {/* Tab 1: 3D Textures & Reference Landmarks */}
          {activeTab === 'relief' && (
            <div className="space-y-3 text-xs font-mono">
              {/* 3D Displacement Height Slider */}
              <div className="space-y-1">
                <div className="flex justify-between text-zinc-400">
                  <span className="flex items-center gap-1.5">
                    <Mountain size={13} className="text-cyan-400" />
                    <span>3D Physical Surface Relief / Displacement:</span>
                  </span>
                  <span className="text-cyan-300 font-semibold">
                    {reliefScale <= 0.1
                      ? 'Subtle (1.0×)'
                      : reliefScale <= 0.22
                      ? 'Realistic (2.0×)'
                      : reliefScale <= 0.34
                      ? 'Enhanced 3D (3.0×)'
                      : 'Dramatic Massifs (4.0×)'}
                  </span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.42"
                  step="0.01"
                  value={reliefScale}
                  onChange={e => setReliefScale(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-700 rounded-lg"
                  aria-label="3D surface displacement scale"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>0.05 (Smooth)</span>
                  <span>0.18 (NASA Scale)</span>
                  <span>0.30 (Terraces &amp; Massifs)</span>
                  <span>0.42 (Extreme Relief)</span>
                </div>
              </div>

              {/* Reference Landmark Selector */}
              <div className="space-y-1.5 pt-1 border-t border-white/10">
                <div className="flex items-center justify-between">
                  <span className="text-zinc-400 flex items-center gap-1">
                    <ImageIcon size={12} className="text-amber-400" />
                    <span>Fly to Reference 3D Features (from NASA Reconnaissance):</span>
                  </span>
                  {selectedLandmarkId && (
                    <button
                      onClick={() => {
                        setSelectedLandmarkId(null);
                        setCameraPreset('cinematic');
                      }}
                      className="text-[10px] text-zinc-400 hover:text-white flex items-center gap-1"
                    >
                      <RotateCcw size={10} />
                      <span>Reset to Full Globe</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-1.5">
                  {LUNAR_LANDMARKS.map(landmark => {
                    const isSelected = selectedLandmarkId === landmark.id;
                    return (
                      <button
                        key={landmark.id}
                        onClick={() => {
                          setSelectedLandmarkId(landmark.id);
                          setShowReferenceCard(true);
                          setSunPhaseAngle(landmark.idealSunAngleDeg);
                        }}
                        className={`px-2 py-1.5 rounded-lg border text-left flex flex-col justify-between transition-all ${
                          isSelected
                            ? 'bg-amber-950/50 border-amber-400/80 text-amber-100 shadow-md ring-1 ring-amber-400/30'
                            : 'border-white/10 hover:border-white/20 hover:bg-white/5 text-zinc-300'
                        }`}
                      >
                        <span className="font-semibold text-[11px] truncate">{landmark.name}</span>
                        <span className="text-[9px] text-zinc-400 truncate">{landmark.referenceCredit.split('/')[0]}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Solar Phase & Terminator Shadowing */}
          {activeTab === 'sun' && (
            <div className="space-y-2 text-xs font-mono">
              <div className="flex justify-between text-zinc-400">
                <span>Solar Angle (Terminator Position &amp; Crater Rim Shadows)</span>
                <span className="text-zinc-200 font-semibold">{Math.round(sunPhaseAngle)}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                step="1"
                value={sunPhaseAngle}
                onChange={e => setSunPhaseAngle(parseFloat(e.target.value))}
                className="w-full accent-amber-400 cursor-pointer h-1.5 bg-zinc-700 rounded-lg"
                aria-label="Solar illumination angle"
              />
              <div className="flex gap-2 pt-1 overflow-x-auto">
                {[
                  { label: 'Full Moon', angle: 0 },
                  { label: 'Waxing Gibbous', angle: 55 },
                  { label: 'First Quarter (Deep Relief)', angle: 90 },
                  { label: 'New Moon (Rim Glow)', angle: 180 },
                  { label: 'Last Quarter (Shadowed Basins)', angle: 270 },
                ].map(preset => (
                  <button
                    key={preset.label}
                    onClick={() => setSunPhaseAngle(preset.angle)}
                    className={`px-2.5 py-1 rounded text-[11px] border whitespace-nowrap ${
                      Math.abs(sunPhaseAngle - preset.angle) < 15
                        ? 'border-amber-400/50 bg-amber-950/40 text-amber-200'
                        : 'border-white/10 text-zinc-400 hover:bg-white/5'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: Camera View Presets */}
          {activeTab === 'camera' && (
            <div className="flex items-center justify-between flex-wrap gap-2 text-xs font-mono">
              <span className="text-zinc-400 text-[11px]">Vantage Points:</span>
              <div className="flex gap-1.5 flex-wrap">
                {[
                  { id: 'cinematic', label: 'Equatorial Orbit' },
                  { id: 'terminator', label: 'Terminator Ridge' },
                  { id: 'apollo', label: 'Apollo 11 Base' },
                  { id: 'polar', label: 'South Pole Basin' },
                  { id: 'farside', label: 'Far Side Basin' },
                  { id: 'overview', label: 'Lunar Overview' },
                ].map(view => (
                  <button
                    key={view.id}
                    onClick={() => {
                      setSelectedLandmarkId(null);
                      setCameraPreset(view.id);
                    }}
                    className={`px-3 py-1 rounded border text-[11px] transition-colors ${
                      cameraPreset === view.id && selectedLandmarkId === null
                        ? 'border-white/40 bg-white/20 text-white font-medium'
                        : 'border-white/10 text-zinc-400 hover:bg-white/5'
                    }`}
                  >
                    {view.label}
                  </button>
                ))}
                <button
                  onClick={() => {
                    setSelectedLandmarkId(null);
                    setCameraPreset('cinematic');
                  }}
                  className="px-2.5 py-1 rounded border border-white/10 text-zinc-400 hover:text-white hover:bg-white/5 text-[11px] flex items-center gap-1"
                  title="Reset view"
                >
                  <RotateCcw size={11} />
                  <span>Reset</span>
                </button>
              </div>
            </div>
          )}

          {/* Tab 4: Rotation & Time Drift */}
          {activeTab === 'orbit' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono items-center">
              <div className="space-y-1 md:col-span-2">
                <div className="flex justify-between text-zinc-400">
                  <span>Axial Rotation Speed</span>
                  <span className="text-zinc-200 font-semibold">{speedMultiplier.toFixed(1)}×</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="4.0"
                  step="0.1"
                  value={speedMultiplier}
                  onChange={e => setSpeedMultiplier(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-700 rounded-lg"
                  aria-label="Axial rotation speed multiplier"
                />
                <div className="flex justify-between text-[10px] text-zinc-500">
                  <span>0.1× (Subtle Drift)</span>
                  <span>1.0× (Normal)</span>
                  <span>4.0× (Rapid)</span>
                </div>
              </div>

              <div className="flex items-center gap-2 justify-end">
                <button
                  onClick={() => setShowAxes(!showAxes)}
                  className={`flex-1 py-1.5 px-2.5 rounded-md border text-center transition-colors ${
                    showAxes
                      ? 'bg-cyan-950/60 border-cyan-500/40 text-cyan-300'
                      : 'border-white/10 text-zinc-400 hover:bg-white/5'
                  }`}
                >
                  Polar Axis ({showAxes ? 'ON' : 'OFF'})
                </button>
                <button
                  onClick={() => setShowLandingSites(!showLandingSites)}
                  className={`flex-1 py-1.5 px-2.5 rounded-md border text-center transition-colors ${
                    showLandingSites
                      ? 'bg-amber-950/60 border-amber-500/40 text-amber-300'
                      : 'border-white/10 text-zinc-400 hover:bg-white/5'
                  }`}
                >
                  Landmarks ({showLandingSites ? 'ON' : 'OFF'})
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Floating expand button when Zen mode is active */}
      {isZenMode && (
        <button
          onClick={() => setIsZenMode(false)}
          className="fixed bottom-5 left-1/2 -translate-x-1/2 z-20 px-3.5 py-1.5 rounded-full bg-[#080d14]/85 border border-white/15 text-xs font-mono text-zinc-300 hover:text-white flex items-center gap-1.5 shadow-2xl transition-all hover:scale-105"
          aria-label="Open simulation control dock"
        >
          <ChevronUp size={14} />
          <span>Show Controls</span>
        </button>
      )}
    </>
  );
};
