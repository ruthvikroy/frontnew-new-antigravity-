import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  calculateAxialRotation,
  calculateSubsolarPoint,
  calculateLunarPhase,
  selenographicToCartesian,
  LUNAR_LANDMARKS,
  LUNAR_AXIAL_TILT_RAD,
} from '../utils/orbitalMath.js';
import { createPhotorealisticMoonTextures, createStarfieldBackground } from './proceduralMoon.js';

export const MoonSimulation = ({
  speedMultiplier,
  isPaused,
  showAxes,
  showLandingSites,
  reliefScale,
  cameraPreset,
  selectedLandmarkId,
  sunPhaseAngle,
  onTelemetryUpdate,
}) => {
  const mountRef = useRef(null);
  const propsRef = useRef({
    speedMultiplier,
    isPaused,
    showAxes,
    showLandingSites,
    reliefScale,
    cameraPreset,
    selectedLandmarkId,
    sunPhaseAngle,
    onTelemetryUpdate,
  });

  // Keep propsRef in sync without tearing down the WebGL canvas
  useEffect(() => {
    propsRef.current = {
      speedMultiplier,
      isPaused,
      showAxes,
      showLandingSites,
      reliefScale,
      cameraPreset,
      selectedLandmarkId,
      sunPhaseAngle,
      onTelemetryUpdate,
    };
  });

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Detect Software WebGL
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    // 2. Scene & Renderer setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x020306, 0.0012);

    const camera = new THREE.PerspectiveCamera(
      40,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 1.8, 11.8);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
      preserveDrawingBuffer: true,
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isSoftwareGl ? 1.0 : 1.75));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 3. Realistic OrbitControls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 3.6; // keep user outside the physical lunar crust
    controls.maxDistance = 55.0;
    controls.enablePan = true;
    controls.maxPolarAngle = Math.PI - 0.01;

    // 4. Subtle IBL Environment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    pmremGenerator.compileEquirectangularShader();
    const envScene = new RoomEnvironment();
    const envMap = pmremGenerator.fromScene(envScene, 0.04).texture;
    scene.environment = envMap;
    pmremGenerator.dispose();

    // 5. Lighting: Distant Solar Illuminator with crisp shadows
    const sunLight = new THREE.DirectionalLight(0xfffaed, 2.8);
    sunLight.castShadow = !isSoftwareGl;
    sunLight.shadow.mapSize.width = isSoftwareGl ? 512 : 2048;
    sunLight.shadow.mapSize.height = isSoftwareGl ? 512 : 2048;
    sunLight.shadow.bias = -0.0004;
    sunLight.shadow.camera.near = 5;
    sunLight.shadow.camera.far = 80;
    sunLight.shadow.camera.left = -6;
    sunLight.shadow.camera.right = 6;
    sunLight.shadow.camera.top = 6;
    sunLight.shadow.camera.bottom = -6;
    scene.add(sunLight);

    // Deep cosmic space fill (low ambient to maintain crisp lunar shadow blacks)
    const spaceFill = new THREE.DirectionalLight(0x1a243b, 0.22);
    spaceFill.position.set(0, -10, -10);
    scene.add(spaceFill);

    const ambientLight = new THREE.AmbientLight(0x080c14, 0.16);
    scene.add(ambientLight);

    // 6. Realistic Starfield Background
    const { geometry: starsGeom, material: starsMat } = createStarfieldBackground(isSoftwareGl ? 2200 : 5500);
    const starfield = new THREE.Points(starsGeom, starsMat);
    scene.add(starfield);

    // Distant Earth in the background (Earthrise perspective)
    const earthGroup = new THREE.Group();
    earthGroup.position.set(38, 16, -55);
    const earthGeom = new THREE.SphereGeometry(2.4, 32, 32);
    const earthMat = new THREE.MeshStandardMaterial({
      color: 0x224488,
      roughness: 0.6,
      metalness: 0.1,
    });
    const earthMesh = new THREE.Mesh(earthGeom, earthMat);
    earthGroup.add(earthMesh);

    // Earth atmosphere halo
    const earthHaloGeom = new THREE.SphereGeometry(2.55, 32, 32);
    const earthHaloMat = new THREE.MeshBasicMaterial({
      color: 0x4fa3e3,
      transparent: true,
      opacity: 0.35,
      side: THREE.BackSide,
      blending: THREE.AdditiveBlending,
    });
    const earthHalo = new THREE.Mesh(earthHaloGeom, earthHaloMat);
    earthGroup.add(earthHalo);
    scene.add(earthGroup);

    // 7. Photorealistic Moon Model with PBR Textures and True Surface Relief
    const moonGroup = new THREE.Group();
    moonGroup.rotation.z = LUNAR_AXIAL_TILT_RAD; // apply real 1.543° axial tilt
    scene.add(moonGroup);

    const moonRadius = 3.0;
    // Higher geometry resolution for physical vertex displacement
    const seg = isSoftwareGl ? 64 : 128;
    const moonGeom = new THREE.SphereGeometry(moonRadius, seg, seg);

    // Create 3D textures with NASA reference imagery data
    const textures = createPhotorealisticMoonTextures(isSoftwareGl ? 1024 : 2048);

    const initialRelief = propsRef.current.reliefScale;
    const moonMat = new THREE.MeshStandardMaterial({
      map: textures.diffuseMap,
      displacementMap: textures.displacementMap,
      displacementScale: initialRelief,
      displacementBias: -initialRelief * 0.45,
      normalMap: textures.normalMap,
      normalScale: new THREE.Vector2(1.5 + initialRelief * 4.5, 1.5 + initialRelief * 4.5),
      bumpMap: textures.bumpMap,
      bumpScale: 0.08,
      roughnessMap: textures.roughnessMap,
      roughness: 0.92,
      metalness: 0.04,
    });

    const moonMesh = new THREE.Mesh(moonGeom, moonMat);
    moonMesh.castShadow = true;
    moonMesh.receiveShadow = true;
    moonGroup.add(moonMesh);

    // 8. Delicate Lunar Exosphere / Sodium Tail Limb Glow Shader
    const exosphereGeom = new THREE.SphereGeometry(moonRadius * 1.025, 48, 48);
    const exosphereMat = new THREE.ShaderMaterial({
      uniforms: {
        glowColor: { value: new THREE.Color(0xa5c4e8) },
        viewVector: { value: new THREE.Vector3() },
      },
      vertexShader: `
        varying vec3 vNormal;
        varying vec3 vPosition;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          vPosition = (modelViewMatrix * vec4(position, 1.0)).xyz;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        varying vec3 vPosition;
        uniform vec3 glowColor;
        void main() {
          vec3 viewDir = normalize(-vPosition);
          float intensity = pow(1.0 - max(0.0, dot(vNormal, viewDir)), 3.2) * 0.26;
          gl_FragColor = vec4(glowColor, intensity);
        }
      `,
      side: THREE.BackSide,
      blending: THREE.AdditiveBlending,
      transparent: true,
      depthWrite: false,
    });
    const exosphereMesh = new THREE.Mesh(exosphereGeom, exosphereMat);
    moonGroup.add(exosphereMesh);

    // Polar Axis Vector Visualizer
    const axisGroup = new THREE.Group();
    const axisGeom = new THREE.CylinderGeometry(0.015, 0.015, moonRadius * 2.8, 8);
    const axisMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.55,
    });
    const axisMesh = new THREE.Mesh(axisGeom, axisMat);
    axisGroup.add(axisMesh);

    const northDotGeom = new THREE.SphereGeometry(0.06, 12, 12);
    const northDotMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const northDot = new THREE.Mesh(northDotGeom, northDotMat);
    northDot.position.y = moonRadius * 1.4;
    axisGroup.add(northDot);
    moonGroup.add(axisGroup);

    // Landmark markers group (Apollo 11, Copernicus, Tycho, etc.)
    const landmarkMarkersGroup = new THREE.Group();
    moonMesh.add(landmarkMarkersGroup); // Add directly inside moonMesh so it rotates automatically

    // Add visual beacons for reference landmarks
    for (const landmark of LUNAR_LANDMARKS) {
      const pos = selenographicToCartesian(
        landmark.selenographic.latitudeDeg,
        landmark.selenographic.longitudeDeg,
        moonRadius
      );
      const posVec = new THREE.Vector3(pos.x, pos.y, pos.z);

      const markerPin = new THREE.Mesh(
        new THREE.CylinderGeometry(0.007, 0.002, 0.18, 6),
        new THREE.MeshBasicMaterial({
          color: landmark.id === 'earthrise' ? 0x38bdf8 : landmark.id === 'komarov' ? 0xa855f7 : 0xf59e0b,
        })
      );
      markerPin.position.copy(posVec).multiplyScalar(1.025);
      markerPin.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), posVec.clone().normalize());

      const markerRing = new THREE.Mesh(
        new THREE.RingGeometry(0.035, 0.055, 18),
        new THREE.MeshBasicMaterial({
          color: landmark.id === 'earthrise' ? 0x38bdf8 : landmark.id === 'komarov' ? 0xa855f7 : 0xf59e0b,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.65,
        })
      );
      markerRing.position.copy(posVec).multiplyScalar(1.008);
      markerRing.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), posVec.clone().normalize());

      landmarkMarkersGroup.add(markerPin);
      landmarkMarkersGroup.add(markerRing);
    }

    // 9. Animation Loop & Camera Kinematics
    let frameId = 0;
    let lastTime = performance.now();
    let simElapsedSeconds = 0;
    let currentSunAngleRad = (propsRef.current.sunPhaseAngle * Math.PI) / 180;

    const targetCamPos = new THREE.Vector3();
    const targetLookAt = new THREE.Vector3();
    let isTransitioningCamera = false;

    // Reusable math helpers (zero GC)
    const _sunVec = new THREE.Vector3();
    const _obsVec = new THREE.Vector3();
    const _landmarkWorldPos = new THREE.Vector3();

    function updateCameraTarget(preset, landmarkId) {
      if (landmarkId) {
        const landmark = LUNAR_LANDMARKS.find(l => l.id === landmarkId);
        if (landmark) {
          const localPos = selenographicToCartesian(
            landmark.selenographic.latitudeDeg,
            landmark.selenographic.longitudeDeg,
            moonRadius
          );
          _landmarkWorldPos.set(localPos.x, localPos.y, localPos.z);
          _landmarkWorldPos.applyAxisAngle(new THREE.Vector3(0, 1, 0), moonMesh.rotation.y);
          _landmarkWorldPos.applyAxisAngle(new THREE.Vector3(0, 0, 1), LUNAR_AXIAL_TILT_RAD);

          targetLookAt.copy(_landmarkWorldPos);

          if (landmarkId === 'earthrise') {
            targetCamPos.copy(_landmarkWorldPos).multiplyScalar(1.28).add(new THREE.Vector3(1.0, 0.4, 1.8));
          } else {
            const normal = _landmarkWorldPos.clone().normalize();
            targetCamPos.copy(_landmarkWorldPos).add(normal.multiplyScalar(1.6)).add(new THREE.Vector3(0.5, 0.6, 0.8));
          }
          isTransitioningCamera = true;
          return;
        }
      }

      if (preset === 'cinematic') {
        targetCamPos.set(0, 1.8, 11.8);
        targetLookAt.set(0, 0, 0);
      } else if (preset === 'terminator') {
        targetCamPos.set(3.2, 0.9, 4.8);
        targetLookAt.set(1.2, 0.1, 1.5);
      } else if (preset === 'apollo') {
        targetCamPos.set(1.5, 0.7, 4.4);
        targetLookAt.set(0.5, 0.1, 2.5);
      } else if (preset === 'polar') {
        targetCamPos.set(0.4, -9.8, 3.8);
        targetLookAt.set(0, 0, 0);
      } else if (preset === 'farside') {
        targetCamPos.set(-2.2, 1.4, -9.8);
        targetLookAt.set(0, 0, 0);
      } else if (preset === 'overview') {
        targetCamPos.set(0, 4.5, 17.5);
        targetLookAt.set(0, 0, 0);
      }
      isTransitioningCamera = true;
    }

    // Initial camera positioning
    updateCameraTarget(propsRef.current.cameraPreset, propsRef.current.selectedLandmarkId);

    // Software WebGL pacing helper
    function afterDraw(cb) {
      const gl = renderer.getContext();
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    let lastPreset = propsRef.current.cameraPreset;
    let lastLandmarkId = propsRef.current.selectedLandmarkId;

    function tick() {
      const now = performance.now();
      const dt = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      const {
        speedMultiplier,
        isPaused,
        showAxes,
        showLandingSites,
        reliefScale,
        cameraPreset,
        selectedLandmarkId,
        sunPhaseAngle,
        onTelemetryUpdate,
      } = propsRef.current;

      // Update 3D displacement scale dynamically
      if (moonMat.displacementScale !== reliefScale) {
        moonMat.displacementScale = reliefScale;
        moonMat.displacementBias = -reliefScale * 0.45;
        const normFactor = 1.4 + reliefScale * 4.5;
        moonMat.normalScale.set(normFactor, normFactor);
        moonMat.needsUpdate = true;
      }

      // Handle preset or landmark changes
      if (cameraPreset !== lastPreset || selectedLandmarkId !== lastLandmarkId) {
        lastPreset = cameraPreset;
        lastLandmarkId = selectedLandmarkId;
        updateCameraTarget(cameraPreset, selectedLandmarkId);
      }

      // Visibility toggles
      axisGroup.visible = showAxes;
      landmarkMarkersGroup.visible = showLandingSites;

      // Advance simulation time
      if (!isPaused) {
        simElapsedSeconds += dt * speedMultiplier;
      }

      // 1. Lunar Rotation around Polar Axis
      const rotationAngle = calculateAxialRotation(simElapsedSeconds, 1.0, 140);
      moonMesh.rotation.y = rotationAngle;

      // 2. Sun Light Position based on sunPhaseAngle
      currentSunAngleRad = (sunPhaseAngle * Math.PI) / 180;
      const sunDist = 35;
      sunLight.position.set(
        Math.sin(currentSunAngleRad) * sunDist,
        2.5,
        Math.cos(currentSunAngleRad) * sunDist
      );

      // 3. Camera target tracking (landmarks or preset lerp)
      if (selectedLandmarkId) {
        const landmark = LUNAR_LANDMARKS.find(l => l.id === selectedLandmarkId);
        if (landmark) {
          const localPos = selenographicToCartesian(
            landmark.selenographic.latitudeDeg,
            landmark.selenographic.longitudeDeg,
            moonRadius
          );
          _landmarkWorldPos.set(localPos.x, localPos.y, localPos.z);
          _landmarkWorldPos.applyAxisAngle(new THREE.Vector3(0, 1, 0), moonMesh.rotation.y);
          _landmarkWorldPos.applyAxisAngle(new THREE.Vector3(0, 0, 1), LUNAR_AXIAL_TILT_RAD);

          targetLookAt.copy(_landmarkWorldPos);
          const normal = _landmarkWorldPos.clone().normalize();
          targetCamPos.copy(_landmarkWorldPos).add(normal.multiplyScalar(landmark.id === 'earthrise' ? 2.5 : 1.7));
          isTransitioningCamera = true;
        }
      }

      if (isTransitioningCamera) {
        camera.position.lerp(targetCamPos, 0.04);
        controls.target.lerp(targetLookAt, 0.05);
        if (camera.position.distanceTo(targetCamPos) < 0.05) {
          isTransitioningCamera = false;
        }
      }

      controls.update();

      // 4. Exosphere glow view vector update
      if (exosphereMat.uniforms.viewVector) {
        _sunVec.copy(camera.position).normalize();
        exosphereMat.uniforms.viewVector.value = _sunVec;
      }

      // 5. Earth slow gentle spin
      earthMesh.rotation.y += dt * 0.02;

      // Render
      renderer.render(scene, camera);

      // Telemetry updates
      if (Math.random() < 0.2 && onTelemetryUpdate) {
        _obsVec.copy(camera.position);
        const observerAngle = Math.atan2(_obsVec.z, _obsVec.x);
        const phase = calculateLunarPhase(currentSunAngleRad, observerAngle);
        const subsolar = calculateSubsolarPoint(currentSunAngleRad, rotationAngle);

        let activeName = 'Lunar 3D Surface';
        if (selectedLandmarkId) {
          const lm = LUNAR_LANDMARKS.find(l => l.id === selectedLandmarkId);
          if (lm) activeName = lm.name;
        } else if (cameraPreset === 'apollo') {
          activeName = 'Tranquility Base (Apollo 11)';
        } else if (cameraPreset === 'terminator') {
          activeName = 'Lunar Terminator Edge';
        } else if (cameraPreset === 'farside') {
          activeName = 'Far Side (Komarov Basin)';
        } else if (cameraPreset === 'polar') {
          activeName = 'South Pole Aitken Basin';
        }

        onTelemetryUpdate({
          elapsedTime: simElapsedSeconds,
          rotationAngleDeg: Number(((rotationAngle * 180) / Math.PI).toFixed(1)),
          rotationSpeedMultiplier: speedMultiplier,
          subsolar,
          phase,
          activeEntityName: activeName,
        });
      }

      // Software WebGL pacing
      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    // Start loop
    if (isSoftwareGl) {
      afterDraw(tick);
    } else {
      frameId = requestAnimationFrame(tick);
    }

    // Window resize handler
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (frameId) {
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);
      }
      controls.dispose();
      starsGeom.dispose();
      starsMat.dispose();
      moonGeom.dispose();
      moonMat.dispose();
      exosphereGeom.dispose();
      exosphereMat.dispose();
      earthGeom.dispose();
      earthMat.dispose();
      earthHaloGeom.dispose();
      earthHaloMat.dispose();
      axisGeom.dispose();
      axisMat.dispose();
      northDotGeom.dispose();
      northDotMat.dispose();
      textures.diffuseMap.dispose();
      textures.displacementMap.dispose();
      textures.normalMap.dispose();
      textures.bumpMap.dispose();
      textures.roughnessMap.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement) {
        renderer.domElement.parentElement.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="w-full h-full absolute inset-0 cursor-grab active:cursor-grabbing overflow-hidden select-none bg-[#030508]"
      data-testid="moon-webgl-canvas-container"
    />
  );
};
