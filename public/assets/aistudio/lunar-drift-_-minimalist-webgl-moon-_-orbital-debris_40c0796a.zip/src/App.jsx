import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { MoonSimulation } from './components/MoonSimulation.jsx';
import { MinimalHUD } from './components/MinimalHUD.jsx';
import { SpaceAudioEngine } from './components/AudioEngine.js';
import { GoogleDrivePanel } from './components/GoogleDrivePanel.jsx';

export default function App() {
  const [speedMultiplier, setSpeedMultiplier] = useState(1.0);
  const [isPaused, setIsPaused] = useState(false);
  const [showAxes, setShowAxes] = useState(false);
  const [showLandingSites, setShowLandingSites] = useState(true);
  const [reliefScale, setReliefScale] = useState(0.22); // 3D physical surface relief
  const [cameraPreset, setCameraPreset] = useState('cinematic');
  const [selectedLandmarkId, setSelectedLandmarkId] = useState(null);
  const [sunPhaseAngle, setSunPhaseAngle] = useState(65); // classic dramatic crater terminator illumination
  const [telemetry, setTelemetry] = useState(null);
  const [isAudioActive, setIsAudioActive] = useState(false);
  const [isZenMode, setIsZenMode] = useState(false);
  const [isDriveOpen, setIsDriveOpen] = useState(false);

  const audioEngineRef = useRef(null);

  useEffect(() => {
    audioEngineRef.current = new SpaceAudioEngine();
    return () => {
      audioEngineRef.current?.dispose();
    };
  }, []);

  const handleToggleAudio = useCallback(() => {
    if (audioEngineRef.current) {
      const active = audioEngineRef.current.toggle();
      setIsAudioActive(active);
    }
  }, []);

  const handleTelemetryUpdate = useCallback((data) => {
    setTelemetry(data);
  }, []);

  const currentPreset = useMemo(
    () => ({
      version: 1,
      savedAt: new Date().toISOString(),
      speedMultiplier,
      reliefScale,
      sunPhaseAngle,
      cameraPreset,
      selectedLandmarkId,
      showAxes,
      showLandingSites,
    }),
    [
      speedMultiplier,
      reliefScale,
      sunPhaseAngle,
      cameraPreset,
      selectedLandmarkId,
      showAxes,
      showLandingSites,
    ]
  );

  const handleApplyPreset = useCallback((preset) => {
    if (typeof preset.speedMultiplier === 'number') setSpeedMultiplier(preset.speedMultiplier);
    if (typeof preset.reliefScale === 'number') setReliefScale(preset.reliefScale);
    if (typeof preset.sunPhaseAngle === 'number') setSunPhaseAngle(preset.sunPhaseAngle);
    if (preset.cameraPreset) setCameraPreset(preset.cameraPreset);
    setSelectedLandmarkId(preset.selectedLandmarkId ?? null);
    if (typeof preset.showAxes === 'boolean') setShowAxes(preset.showAxes);
    if (typeof preset.showLandingSites === 'boolean') setShowLandingSites(preset.showLandingSites);
  }, []);

  const handleCaptureCanvasDataUrl = useCallback(() => {
    const container = document.querySelector('[data-testid="moon-webgl-canvas-container"]');
    const canvas = container?.querySelector('canvas');
    if (!canvas) return null;
    try {
      return canvas.toDataURL('image/png');
    } catch {
      return null;
    }
  }, []);

  // Keyboard shortcuts:
  // H -> Zen mode toggle
  // Space -> Pause/Resume
  // 1, 2, 3, 4, 5, 6 -> Camera Presets
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      if (e.key === 'h' || e.key === 'H') {
        setIsZenMode(prev => !prev);
      } else if (e.code === 'Space') {
        e.preventDefault();
        setIsPaused(prev => !prev);
      } else if (e.key === '1') {
        setSelectedLandmarkId(null);
        setCameraPreset('cinematic');
      } else if (e.key === '2') {
        setSelectedLandmarkId(null);
        setCameraPreset('terminator');
      } else if (e.key === '3') {
        setSelectedLandmarkId(null);
        setCameraPreset('apollo');
      } else if (e.key === '4') {
        setSelectedLandmarkId(null);
        setCameraPreset('polar');
      } else if (e.key === '5') {
        setSelectedLandmarkId(null);
        setCameraPreset('farside');
      } else if (e.key === '6') {
        setSelectedLandmarkId(null);
        setCameraPreset('overview');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-black font-sans">
      {/* 3D WebGL Canvas Layer with Physical Surface Relief */}
      <MoonSimulation
        speedMultiplier={speedMultiplier}
        isPaused={isPaused}
        showAxes={showAxes}
        showLandingSites={showLandingSites}
        reliefScale={reliefScale}
        cameraPreset={cameraPreset}
        selectedLandmarkId={selectedLandmarkId}
        sunPhaseAngle={sunPhaseAngle}
        onTelemetryUpdate={handleTelemetryUpdate}
      />

      {/* Ergonomic Minimalist HUD & Controls */}
      <MinimalHUD
        telemetry={telemetry}
        speedMultiplier={speedMultiplier}
        setSpeedMultiplier={setSpeedMultiplier}
        isPaused={isPaused}
        setIsPaused={setIsPaused}
        reliefScale={reliefScale}
        setReliefScale={setReliefScale}
        showAxes={showAxes}
        setShowAxes={setShowAxes}
        showLandingSites={showLandingSites}
        setShowLandingSites={setShowLandingSites}
        cameraPreset={cameraPreset}
        setCameraPreset={setCameraPreset}
        selectedLandmarkId={selectedLandmarkId}
        setSelectedLandmarkId={setSelectedLandmarkId}
        sunPhaseAngle={sunPhaseAngle}
        setSunPhaseAngle={setSunPhaseAngle}
        isAudioActive={isAudioActive}
        onToggleAudio={handleToggleAudio}
        isZenMode={isZenMode}
        setIsZenMode={setIsZenMode}
        onOpenDrive={() => setIsDriveOpen(true)}
      />

      {/* Google Drive Archive & Preset Manager Modal */}
      <GoogleDrivePanel
        isOpen={isDriveOpen}
        onClose={() => setIsDriveOpen(false)}
        currentPreset={currentPreset}
        onApplyPreset={handleApplyPreset}
        onCaptureCanvasDataUrl={handleCaptureCanvasDataUrl}
      />
    </main>
  );
}
