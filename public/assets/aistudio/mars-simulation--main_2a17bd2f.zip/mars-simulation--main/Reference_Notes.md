# Reference Notes — Technical Specifications, NASA Mars Assets & Perseverance 3D Texture Dataset

## 1. Reference Media & Catalog Identifiers
1. **Global Mars Mosaic (`/assets/aistudio/1-mars-nasa-gov-jpg_e2a27276.webp` / `1-mars-nasa-gov-jpg.webp`)**
   - **Source**: NASA / USGS / Viking & MGS Global Mosaic (`science.nasa.gov/mars`)
   - **3D Texture Role**: Macro-scale 360° albedo and luminance-to-elevation canyon/volcano relief across Valles Marineris, Tharsis Montes, and Syrtis Major.
2. **Perseverance Mastcam-Z Stereo Pairs (`ZL0` & `ZR0` Sol 2020 — `ZCAM10053`)**
   - **Files**: `Mars_Perseverance_ZL0/ZR0_2020_0846263599..644_193ECM/EBY_N0920000ZCAM10053_0480LMJ.png`
   - **3D Texture Role**: Left/Right stereo disparity reconstruction of angular Martian rocks, wind-blown aeolian regolith ripples, and the circular abraded rock patch with a 16mm core drill hole and bright tailings.
3. **Perseverance Jezero Delta Outcrops & Boulders (`ZCAM08693`, `ZCAM03527`, `ZCAM08750`, `ZCAM08614`, `PIA26202`)**
   - **Files**: `ZL0_0695_...ZCAM08693`, `ZR0_0682_...ZCAM03527`, `ZR0_0739_...ZCAM08750`, `ZL0_0606_...ZCAM08614`, `1-pia26202-perseverances-parking-spot-during-conjunction.webp`
   - **3D Texture Role**: Diagonal cross-bedded sandstone laminae, Kodiak deltaic escarpment strata, wind-sculpted "Sombrero" pedestal rocks, and rounded alluvial boulder fields.
4. **Perseverance SuperCam Remote Micro-Imager (`SCAM04020` / `SCAM01021`) & MEDA SkyCam (`MEDA00000`)**
   - **Files**: `Mars_Perseverance_LRE/LRF_2020_0846288691_...SCAM04020`, `LRE/LRF_2021_0846352827_...SCAM01021`, `Mars_Perseverance_WSM_2020_0846277167_...MEDA00000`
   - **3D Texture & Atmosphere Role**: Sub-millimeter vesicular & crystalline grain micro-relief (`bumpMap`) and upward-looking MEDA SkyCam concentric solar scattering ring calibrating the semi-transparent atmospheric layer.
5. **Perseverance at "Cheyava Falls" (`/assets/aistudio/pia26344-1600x_c40461b6.webp` — `PIA26344`)**, **Curiosity at "Buckskin" (`/assets/aistudio/32322_mars-curiosity-rover-msl-horizon-sky-self-portrait-PIA19808-full_d447c1a3.jpg` — `PIA19808`)**, & **2001 Mars Odyssey (`/assets/aistudio/mars-odyssey-orbiter-pia04816_c33d5cdc.webp` — `PIA04816`)**
   - **Role**: Primary mission landmarks, 3D spacecraft reference model, and regional surface stamps.
6. **NASA Science Mars Video Briefing (`https://www.youtube.com/watch?v=Q_P0swqaZDk&t=27s`)**
   - **Source**: NASA / Jet Propulsion Laboratory (`science.nasa.gov`)

## 2. Atmospheric & Procedural Cloud Shader Specifications
- **Inner Thin Semi-Transparent Atmosphere & Cloud Layer (`r = 3.045`, `1.015 × R_Mars`)**:
  - 3D spherical 5-octave Fractional Brownian Motion (fBm) with domain warping.
  - Simulates the **Aphelion Water-Ice Cloud Belt** (`-25°S` to `+25°N`), **Tharsis & Olympus Mons Orographic Lee-Wave Plumes**, and **Planum Boreum/Australe Polar Hood Clouds**.
  - Includes directional solar self-shadowing, surface drop-shadows, and a thin semi-transparent Fresnel atmospheric envelope.
- **Outer Optical Limb Halo (`r = 3.114`, `1.038 × R_Mars`)**:
  - Models butterscotch ferric-oxide dust scattering on the sunlit limb and cobalt-blue Rayleigh scattering across the twilight terminator.

## 3. UI/UX & Safety Compliance Rules
- **Color Palette**: Deep Space Charcoal/Navy (`#060911` / `#111827`) with Crimson Red (`#dc2626` / `#ef4444`) and Cobalt Blue (`#2563eb` / `#3b82f6`). **Zero Teal / Cyan**.
- **GenAI Safety Settings**: `BLOCK_NONE` across all harm categories.
