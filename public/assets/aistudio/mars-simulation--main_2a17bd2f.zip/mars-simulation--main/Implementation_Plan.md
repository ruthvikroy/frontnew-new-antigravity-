# Implementation Plan — Martian Drift: 3D WebGL Mars, Atmospheric Cloud Shader & Multi-Scale 3D Textures

## 1. Architectural Overview
Enhance the **3D Mars Orbital & Surface Reconnaissance Simulation** (`React 19`, `Three.js`, `Tailwind CSS`) with:
1. **Thin, Semi-Transparent Martian Atmospheric Envelope (`r = 1.015 R_Mars`)**: A physical, semi-transparent `FrontSide` atmospheric layer coupled with an outer `BackSide` Rayleigh/Mie forward-scattering limb halo (`r = 1.038 R_Mars`), calibrated to Perseverance's MEDA SkyCam (`N0920000MEDA00000`) and Curiosity's `PIA19808` horizon optics.
2. **Shader-Based Procedural Cloud Pattern Drifting Slowly Over the Surface**: A custom 3D spherical Fractional Brownian Motion (fBm) & domain-warped GLSL shader rendering Martian water-ice cirrus wisps, the aphelion equatorial cloud belt, Tharsis & Olympus Mons orographic lee-wave plumes, and polar hood $\text{CO}_2$ clouds that drift continuously across the surface and cast subtle 3D cloud shadows onto the terrain below.
3. **Multi-Scale 3D Mars Surface Textures (`proceduralMoon.js`)**: Full-sphere equirectangular 3D relief and normal mapping combining the NASA Global Mars Mosaic (`1-mars-nasa-gov-jpg.webp`), Perseverance Mastcam-Z stereo pair DEMs (`ZCAM10053` `ZL0`/`ZR0` cored rock & aeolian ripples), Jezero delta cross-bedded sandstone strata & boulder fields (`ZCAM08693`, `ZCAM03527`, `ZCAM08750`, `PIA26202`), and SuperCam Remote Micro-Imager (`SCAM04020`) micro-grain relief.
4. **Minimal Asteroid & Orbital Footprint (`DebrisField.js`)**: Default to `'minimal'` orbital mode (showing only the 2001 Mars Odyssey Orbiter and Phobos with zero asteroid clutter) and reduce the optional co-orbital Trojan swarm to a minimal 16 distant particles.

## 2. Core Modules & File Roadmap
1. **`/src/utils/orbitalMath.js` & `/src/utils/orbitalMath.test.js`**
   - `MARS_ATMOSPHERE_CONFIG`, `MARS_3D_TEXTURE_MODES`, and `computeCloudDriftOffset`.
2. **`/src/components/proceduralMoon.js`**
   - Multi-hemisphere 360° projection of `1-mars-nasa-gov-jpg_e2a27276.webp` + `PIA26344` + `PIA19808` + `PIA04816` with Perseverance stereo DEM micro-relief (`microBumpMap`).
3. **`/src/components/DebrisField.js`**
   - Initialize in `'minimal'` mode so background asteroids are hidden by default and Mars's atmosphere, drifting clouds, and 3D surface textures take center stage.
4. **`/src/components/MoonSimulation.jsx`, `/src/components/MinimalHUD.jsx`, & `/src/App.jsx`**
   - Add the thin semi-transparent atmosphere & drifting procedural cloud shader, 3D surface texture mode selector, and cloud/atmosphere controls.
