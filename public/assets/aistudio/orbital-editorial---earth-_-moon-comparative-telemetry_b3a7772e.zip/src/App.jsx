import React, { useState, useMemo } from 'react';
import { LOCATION_PAIRS } from './data/locationPairs.js';
import { filterLocationPairs, sortLocationPairs } from './utils/comparator.js';
import { Header } from './components/Header.jsx';
import { HeroSection } from './components/HeroSection.jsx';
import { CelestialRadar } from './components/CelestialRadar.jsx';
import { ControlToolbar } from './components/ControlToolbar.jsx';
import { SideBySideDashboard } from './components/SideBySideDashboard.jsx';
import { BaselinePhysics } from './components/BaselinePhysics.jsx';
import { MetricComparisonDrawer } from './components/MetricComparisonDrawer.jsx';
import { Footer } from './components/Footer.jsx';

export default function App() {
  const [category, setCategory] = useState('all');
  const [criterion, setCriterion] = useState('elevation');
  const [direction, setDirection] = useState('desc');
  const [searchQuery, setSearchQuery] = useState('');
  const [syncScroll, setSyncScroll] = useState(true);
  const [tempUnit, setTempUnit] = useState('C');
  const [soundEnabled, setSoundEnabled] = useState(false);

  const [focusedPairId, setFocusedPairId] = useState(LOCATION_PAIRS[0].id);
  const [detailedPair, setDetailedPair] = useState(null);

  // Synthesized subtle retro telemetry audio click (pure Web Audio API, zero external assets)
  const playTelemetryBlip = () => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.04);

      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.04);
    } catch {
      // AudioContext fallback
    }
  };

  // Filter and sort pure pipeline
  const filteredAndSortedPairs = useMemo(() => {
    const filtered = filterLocationPairs(LOCATION_PAIRS, category, searchQuery);
    return sortLocationPairs(filtered, criterion, direction);
  }, [category, searchQuery, criterion, direction]);

  const focusedPair = useMemo(() => {
    const found = LOCATION_PAIRS.find((p) => p.id === focusedPairId);
    return found || LOCATION_PAIRS[0];
  }, [focusedPairId]);

  const handleResetFilters = () => {
    setCategory('all');
    setSearchQuery('');
    setCriterion('elevation');
    setDirection('desc');
    playTelemetryBlip();
  };

  const handleScrollToMatrix = () => {
    playTelemetryBlip();
    const el = document.getElementById('dashboard');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleScrollToPhysics = () => {
    playTelemetryBlip();
    const el = document.getElementById('physics');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleJumpToTop = () => {
    playTelemetryBlip();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#0c0e11] text-[#e2e2e6] flex flex-col antialiased selection:bg-[#ffcc00]/25 selection:text-[#ffcc00] scroll-smooth">
      {/* 3-Zone Top Navigation Header */}
      <Header
        syncScroll={syncScroll}
        onToggleSyncScroll={() => {
          setSyncScroll(!syncScroll);
          playTelemetryBlip();
        }}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
        onJumpToTop={handleJumpToTop}
        activeCount={filteredAndSortedPairs.length}
      />

      <main className="flex-1 flex flex-col">
        {/* Editorial Hero & KPI Strip */}
        <HeroSection
          onScrollToMatrix={handleScrollToMatrix}
          onScrollToPhysics={handleScrollToPhysics}
        />

        {/* Interactive Celestial Vector Projection Radar */}
        <CelestialRadar
          focusedPair={focusedPair}
          onSelectPair={(pair) => {
            setFocusedPairId(pair.id);
            playTelemetryBlip();
          }}
          allPairs={LOCATION_PAIRS}
        />

        {/* Minimalist Control Toolbar (Category Filter, Sort, Search, Unit Toggle) */}
        <ControlToolbar
          category={category}
          onSelectCategory={(cat) => {
            setCategory(cat);
            playTelemetryBlip();
          }}
          criterion={criterion}
          onSelectCriterion={(crit) => {
            setCriterion(crit);
            playTelemetryBlip();
          }}
          direction={direction}
          onToggleDirection={() => {
            setDirection(direction === 'asc' ? 'desc' : 'asc');
            playTelemetryBlip();
          }}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          totalCount={LOCATION_PAIRS.length}
          filteredCount={filteredAndSortedPairs.length}
          tempUnit={tempUnit}
          onToggleTempUnit={() => {
            setTempUnit(tempUnit === 'C' ? 'F' : 'C');
            playTelemetryBlip();
          }}
        />

        {/* Side-by-Side Dual-Column Comparison Dashboard */}
        <SideBySideDashboard
          pairs={filteredAndSortedPairs}
          tempUnit={tempUnit}
          syncScroll={syncScroll}
          focusedPairId={focusedPair.id}
          onFocusPair={(pair) => setFocusedPairId(pair.id)}
          onOpenDetails={(pair) => {
            setDetailedPair(pair);
            playTelemetryBlip();
          }}
          onResetFilters={handleResetFilters}
          onPlayClick={playTelemetryBlip}
        />

        {/* Astrophysics Reference & Planetary Baseline Invariants */}
        <BaselinePhysics />
      </main>

      {/* Deep Metric Comparison Modal Drawer */}
      <MetricComparisonDrawer
        pair={detailedPair}
        onClose={() => setDetailedPair(null)}
        tempUnit={tempUnit}
      />

      {/* Footer */}
      <Footer />
    </div>
  );
}
