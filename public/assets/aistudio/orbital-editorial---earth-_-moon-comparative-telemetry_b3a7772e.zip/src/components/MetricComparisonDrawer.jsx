import React, { useEffect } from 'react';
import { X, Activity, ShieldAlert, SunMedium, Compass, Orbit } from 'lucide-react';

export function MetricComparisonDrawer({ pair, onClose, tempUnit }) {
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!pair) return null;

  const { earth, moon } = pair;

  const elevationDiff = Math.abs(earth.metrics.elevationMeters - moon.metrics.elevationMeters);
  const gravityRatio = (earth.metrics.gravityMps2 / moon.metrics.gravityMps2).toFixed(2);
  const radiationRatio = (moon.metrics.radiationMsvYear / Math.max(earth.metrics.radiationMsvYear, 0.1)).toFixed(1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl bg-[#111316] border border-white/20 rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        role="dialog"
        aria-modal="true"
        aria-labelledby="drawer-title"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-[#16181d]">
          <div>
            <div className="text-[10px] font-mono-telemetry uppercase tracking-widest text-[#ffcc00] mb-0.5">
              Differential Science Analysis // {pair.categoryLabel}
            </div>
            <h2 id="drawer-title" className="font-editorial text-2xl font-bold text-white">
              {pair.title}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/50 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close comparative modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Side-by-Side Location Identity Banner */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Earth Header Card */}
            <div className="p-4 rounded-lg bg-[#14181f] border border-[#00e5ff]/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono-telemetry text-[#00e5ff] font-semibold tracking-wider">
                  TERRESTRIAL // {earth.designation}
                </span>
                <span className="text-[11px] font-mono-telemetry text-white/40">
                  {earth.coordinatesFormatted}
                </span>
              </div>
              <h3 className="font-editorial text-lg font-bold text-white">{earth.name}</h3>
              <p className="text-xs text-white/60 mt-1">{earth.region}</p>
              <div className="mt-3 text-xs text-white/80 bg-black/40 p-2.5 rounded border border-white/5">
                <span className="text-white/40 font-mono-telemetry text-[10px] block uppercase mb-1">
                  Scientific Mission Value:
                </span>
                {earth.scientificSignificance}
              </div>
            </div>

            {/* Moon Header Card */}
            <div className="p-4 rounded-lg bg-[#1a1711] border border-[#ffcc00]/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-mono-telemetry text-[#ffcc00] font-semibold tracking-wider">
                  SELENOLOGICAL // {moon.designation}
                </span>
                <span className="text-[11px] font-mono-telemetry text-white/40">
                  {moon.coordinatesFormatted}
                </span>
              </div>
              <h3 className="font-editorial text-lg font-bold text-white">{moon.name}</h3>
              <p className="text-xs text-white/60 mt-1">{moon.region}</p>
              <div className="mt-3 text-xs text-white/80 bg-black/40 p-2.5 rounded border border-white/5">
                <span className="text-white/40 font-mono-telemetry text-[10px] block uppercase mb-1">
                  Scientific Mission Value:
                </span>
                {moon.scientificSignificance}
              </div>
            </div>
          </div>

          {/* Comparative Metric Diff Matrix */}
          <div className="space-y-4">
            <h4 className="text-xs font-mono-telemetry uppercase tracking-wider text-white/50">
              Direct Telemetry Variance
            </h4>

            {/* Gravity Differential */}
            <div className="bg-black/40 p-4 rounded-lg border border-white/5">
              <div className="flex justify-between items-center text-xs font-mono-telemetry mb-2">
                <span className="text-white flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-[#00e5ff]" />
                  Surface Gravitational Acceleration
                </span>
                <span className="text-[#ffcc00]">Ratio {gravityRatio} : 1 (6.06x stronger on Earth)</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-[11px] text-white/60 font-mono-telemetry mb-1">
                    <span>Earth ({earth.metrics.gravityMps2} m/s²)</span>
                    <span>100%</span>
                  </div>
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                    <div className="bg-[#00e5ff] h-full w-full rounded-full" />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-[11px] text-white/60 font-mono-telemetry mb-1">
                    <span>Moon ({moon.metrics.gravityMps2} m/s²)</span>
                    <span>16.5%</span>
                  </div>
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                    <div className="bg-[#ffcc00] h-full w-[16.5%] rounded-full" />
                  </div>
                </div>
              </div>
            </div>

            {/* Temperature Swing Comparison */}
            <div className="bg-black/40 p-4 rounded-lg border border-white/5">
              <div className="flex justify-between items-center text-xs font-mono-telemetry mb-2">
                <span className="text-white flex items-center gap-1.5">
                  <SunMedium className="w-3.5 h-3.5 text-[#ffcc00]" />
                  Thermal Dynamic Range (Min → Max)
                </span>
                <span className="text-white/60">
                  Lunar Swing: {Math.abs(moon.metrics.tempMaxCelsius - moon.metrics.tempMinCelsius)}°C
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4 text-xs font-mono-telemetry">
                <div className="p-3 bg-white/5 rounded border border-white/5">
                  <div className="text-white/40 text-[10px] uppercase">Earth Extreme Range</div>
                  <div className="text-[#00e5ff] font-semibold text-sm mt-0.5">
                    {earth.metrics.tempMinCelsius}°C to {earth.metrics.tempMaxCelsius}°C
                  </div>
                  <div className="text-[10px] text-white/40 mt-1">
                    Moderated by atmospheric convective heat circulation.
                  </div>
                </div>
                <div className="p-3 bg-white/5 rounded border border-white/5">
                  <div className="text-white/40 text-[10px] uppercase">Moon Extreme Range</div>
                  <div className="text-[#ffcc00] font-semibold text-sm mt-0.5">
                    {moon.metrics.tempMinCelsius}°C to {moon.metrics.tempMaxCelsius}°C
                  </div>
                  <div className="text-[10px] text-white/40 mt-1">
                    Extreme radiation in vacuum without atmospheric buffer.
                  </div>
                </div>
              </div>
            </div>

            {/* Elevation Difference */}
            <div className="bg-black/40 p-4 rounded-lg border border-white/5">
              <div className="flex justify-between items-center text-xs font-mono-telemetry mb-1">
                <span className="text-white flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-white/60" />
                  Elevation Datum Offset
                </span>
                <span className="text-white font-medium">Δ {elevationDiff.toLocaleString()} meters absolute</span>
              </div>
              <p className="text-xs text-white/60 mt-1">
                Earth reference: Mean Sea Level. Moon reference: Mean radius sphere (1,737.4 km).
              </p>
            </div>

            {/* Radiation Environment */}
            <div className="bg-black/40 p-4 rounded-lg border border-white/5">
              <div className="flex justify-between items-center text-xs font-mono-telemetry mb-1">
                <span className="text-white flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
                  Cosmic & Solar Radiation Exposure
                </span>
                <span className="text-red-400 font-medium">
                  Lunar exposure is ~{radiationRatio}x terrestrial dosage
                </span>
              </div>
              <p className="text-xs text-white/60 mt-1">
                Earth’s magnetosphere shields 99.5% of galactic cosmic rays (GCR). Lunar expeditions require regolith or subterranean basalt shielding.
              </p>
            </div>
          </div>

          {/* Thematic Synthesis Note */}
          <div className="p-4 rounded-lg bg-white/5 border border-white/10">
            <span className="text-white/40 font-mono-telemetry text-[10px] uppercase block mb-1">
              Comparative Frontier Synthesis
            </span>
            <p className="text-sm text-white/90 leading-relaxed font-sans">
              {pair.thematicParallels}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-white/10 bg-[#16181d] flex items-center justify-between">
          <div className="text-[11px] font-mono-telemetry text-white/40">
            Sources: NASA Planetary Data System, LROC, USGS Astrogeology
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-white bg-white/15 rounded hover:bg-white/20 transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
