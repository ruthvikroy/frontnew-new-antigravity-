import React, { useState } from 'react';
import { Globe, Moon, MapPin, Gauge, Thermometer, Radio, Orbit, Clock, Activity, ChevronRight } from 'lucide-react';
import { calculateLunarWeight, calculateLunarJumpHeight } from '../utils/comparator.js';

export function LocationCard({
  location,
  type,
  tempUnit,
  isHovered,
  onFocus,
  onOpenDetails,
  onPlayClick,
}) {
  const [imageError, setImageError] = useState(false);
  const [showGravityCalc, setShowGravityCalc] = useState(false);
  const [userWeight, setUserWeight] = useState(70);
  const isEarth = type === 'earth';

  const convertTemp = (celsius) => {
    if (tempUnit === 'F') {
      return ((celsius * 9) / 5 + 32).toFixed(1);
    }
    return celsius.toFixed(1);
  };

  const accentColor = isEarth ? 'text-[#00e5ff]' : 'text-[#ffcc00]';
  const borderColor = isHovered
    ? isEarth
      ? 'border-[#00e5ff]/50 shadow-[0_0_20px_rgba(0,229,255,0.12)]'
      : 'border-[#ffcc00]/50 shadow-[0_0_20px_rgba(255,204,0,0.12)]'
    : 'border-white/10 hover:border-white/20';

  const feltWeight = isEarth ? userWeight : calculateLunarWeight(userWeight);
  const jumpHeightCm = isEarth ? 45 : calculateLunarJumpHeight(45);

  return (
    <article
      onMouseEnter={() => {
        onFocus();
        if (onPlayClick) onPlayClick();
      }}
      className={`group relative bg-[#131519] border ${borderColor} rounded-lg p-5 flex flex-col justify-between transition-all duration-300 h-full`}
    >
      {/* Top Banner & Image */}
      <div>
        <div className="relative w-full h-44 rounded-md overflow-hidden bg-black/60 mb-4 border border-white/5">
          {!imageError && location.imageUrl ? (
            <img
              src={location.imageUrl}
              alt={location.imageAlt}
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 opacity-80 group-hover:opacity-100"
              loading="lazy"
            />
          ) : (
            // Resilient Styled SVG Fallback Container
            <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-b from-[#181a1f] to-[#0d0f12]">
              {isEarth ? (
                <Globe className="w-12 h-12 text-[#00e5ff]/40 mb-2 stroke-[1.2]" />
              ) : (
                <Moon className="w-12 h-12 text-[#ffcc00]/40 mb-2 stroke-[1.2]" />
              )}
              <span className="text-xs font-mono-telemetry text-white/50 text-center">
                {location.terrainType}
              </span>
            </div>
          )}

          {/* Type Badge & Coordinates Overlay */}
          <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 px-2 py-1 rounded bg-black/80 backdrop-blur-sm border border-white/10 text-[10px] font-mono-telemetry text-white">
            {isEarth ? (
              <span className="text-[#00e5ff] font-semibold">EARTH</span>
            ) : (
              <span className="text-[#ffcc00] font-semibold">MOON</span>
            )}
            <span className="text-white/40">·</span>
            <span className="tracking-wider">{location.designation}</span>
          </div>

          <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded bg-black/80 backdrop-blur-sm border border-white/10 text-[10px] font-mono-telemetry text-white/70 flex items-center gap-1">
            <MapPin className="w-2.5 h-2.5 text-white/40" />
            <span>{location.coordinatesFormatted}</span>
          </div>
        </div>

        {/* Location Identity */}
        <div className="mb-3">
          <div className="text-[11px] font-mono-telemetry text-white/40 uppercase tracking-wider mb-0.5">
            {location.region}
          </div>
          <h4 className="font-editorial text-xl font-bold text-white group-hover:text-white transition-colors">
            {location.name}
          </h4>
          <p className="text-xs text-white/60 mt-1 line-clamp-2 leading-relaxed">
            {location.summary}
          </p>
        </div>

        {/* Telemetry Metric Matrix */}
        <div className="grid grid-cols-2 gap-2 my-4">
          {/* Elevation */}
          <div className="bg-black/30 border border-white/5 rounded p-2.5">
            <div className="flex items-center gap-1 text-[10px] text-white/40 font-mono-telemetry uppercase">
              <Orbit className="w-3 h-3 text-white/30" />
              <span>Elevation</span>
            </div>
            <div className="text-sm font-semibold font-mono-telemetry text-white mt-1">
              {location.metrics.elevationMeters > 0 ? '+' : ''}
              {location.metrics.elevationMeters.toLocaleString()} m
            </div>
            <div className="text-[10px] text-white/30 font-mono-telemetry">
              {isEarth ? 'rel. to sea level' : 'rel. to lunar datum'}
            </div>
          </div>

          {/* Temperature Range */}
          <div className="bg-black/30 border border-white/5 rounded p-2.5">
            <div className="flex items-center gap-1 text-[10px] text-white/40 font-mono-telemetry uppercase">
              <Thermometer className="w-3 h-3 text-white/30" />
              <span>Temp Range</span>
            </div>
            <div className={`text-sm font-semibold font-mono-telemetry mt-1 ${accentColor}`}>
              {convertTemp(location.metrics.tempMinCelsius)}° to {convertTemp(location.metrics.tempMaxCelsius)}°{tempUnit}
            </div>
            <div className="text-[10px] text-white/30 font-mono-telemetry">
              Swing: {Math.abs(location.metrics.tempMaxCelsius - location.metrics.tempMinCelsius).toFixed(0)}°C
            </div>
          </div>

          {/* Gravity */}
          <div className="bg-black/30 border border-white/5 rounded p-2.5">
            <div className="flex items-center gap-1 text-[10px] text-white/40 font-mono-telemetry uppercase">
              <Gauge className="w-3 h-3 text-white/30" />
              <span>Surface Gravity</span>
            </div>
            <div className="text-sm font-semibold font-mono-telemetry text-white mt-1">
              {location.metrics.gravityMps2.toFixed(2)} m/s²
            </div>
            <div className="text-[10px] text-white/30 font-mono-telemetry">
              {isEarth ? '1.000 g' : '0.165 g (1/6th)'}
            </div>
          </div>

          {/* Atmosphere / Comm Delay */}
          <div className="bg-black/30 border border-white/5 rounded p-2.5">
            <div className="flex items-center gap-1 text-[10px] text-white/40 font-mono-telemetry uppercase">
              {isEarth ? (
                <>
                  <Clock className="w-3 h-3 text-white/30" />
                  <span>Atmosphere</span>
                </>
              ) : (
                <>
                  <Radio className="w-3 h-3 text-white/30" />
                  <span>Comm Delay</span>
                </>
              )}
            </div>
            <div className="text-sm font-semibold font-mono-telemetry text-white mt-1">
              {isEarth ? (
                `${location.metrics.atmosphereKpa.toLocaleString()} kPa`
              ) : (
                `${location.metrics.commDelaySeconds}s delay`
              )}
            </div>
            <div className="text-[10px] text-white/30 font-mono-telemetry truncate">
              {isEarth ? 'Standard 1 atm' : 'Exosphere vacuum'}
            </div>
          </div>
        </div>

        {/* Interactive In-Card Gravity Simulator Toggle */}
        <div className="my-2">
          <button
            onClick={() => setShowGravityCalc(!showGravityCalc)}
            className="w-full py-1.5 px-2 bg-white/[0.03] hover:bg-white/[0.07] border border-white/10 rounded text-[11px] font-mono-telemetry text-white/70 hover:text-white flex items-center justify-between transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <Activity className="w-3 h-3 text-[#ffcc00]" />
              <span>Interactive Gravity Simulator</span>
            </span>
            <span className="text-[10px] text-white/40">{showGravityCalc ? 'Hide' : 'Calculate'}</span>
          </button>

          {showGravityCalc && (
            <div className="mt-2 p-3 bg-black/50 border border-white/10 rounded text-xs font-mono-telemetry space-y-2 animate-in fade-in duration-200">
              <div className="flex items-center justify-between gap-2">
                <span className="text-white/50 text-[10px] uppercase">Your Weight (kg):</span>
                <input
                  type="number"
                  min="20"
                  max="250"
                  value={userWeight}
                  onChange={(e) => setUserWeight(Math.max(1, Number(e.target.value) || 0))}
                  className="w-16 px-1.5 py-0.5 bg-black border border-white/20 rounded text-right text-white text-xs focus:outline-none focus:border-[#ffcc00]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/10">
                <div className="bg-white/5 p-1.5 rounded">
                  <span className="text-white/40 block text-[9px] uppercase">Felt Weight</span>
                  <span className="text-white font-semibold">{feltWeight} kg</span>
                </div>
                <div className="bg-white/5 p-1.5 rounded">
                  <span className="text-white/40 block text-[9px] uppercase">Est. Jump</span>
                  <span className={`${accentColor} font-semibold`}>{jumpHeightCm} cm</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Card Action Link */}
      <div className="pt-2 border-t border-white/5 flex items-center justify-between">
        <span className="text-[11px] font-mono-telemetry text-white/40 truncate max-w-[170px]">
          Terrain: <span className="text-white/80">{location.terrainType}</span>
        </span>
        <button
          onClick={onOpenDetails}
          className="text-xs font-mono-telemetry text-white/70 hover:text-white underline underline-offset-4 decoration-white/30 hover:decoration-white transition-all cursor-pointer flex items-center gap-1"
        >
          <span>Inspect Telemetry</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </article>
  );
}
