import React from 'react';

export function Footer() {
  return (
    <footer className="w-full border-t border-white/10 bg-[#0c0e11] py-10 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="font-editorial text-lg font-bold text-white tracking-tight">
            Orbital Editorial
          </div>
          <p className="text-xs text-white/50 mt-1 max-w-md">
            A high-contrast comparative laboratory documenting terrestrial and selenological topography, astrophysics invariants, and planetary exploration analogs.
          </p>
        </div>

        <div className="text-xs font-mono-telemetry text-white/40 text-right space-y-1">
          <div>Data: NASA Planetary Data System, USGS Astrogeology, LROC</div>
          <div>Published for scientific education and exploratory analysis</div>
        </div>
      </div>
    </footer>
  );
}
