import React from 'react';
import { Search, ArrowUpDown, SlidersHorizontal, X, Mountain } from 'lucide-react';

const CATEGORIES = [
  { id: 'all', label: 'All Analog Pairs' },
  { id: 'extreme-terrains', label: 'Extreme Terrains' },
  { id: 'deep-basins', label: 'Deep Basins' },
  { id: 'research-bases', label: 'Research Bases' },
  { id: 'volcanic-subterranean', label: 'Volcanic Tubes' },
  { id: 'historic-sites', label: 'Historic Sites' },
];

export function ControlToolbar({
  category,
  onSelectCategory,
  criterion,
  onSelectCriterion,
  direction,
  onToggleDirection,
  searchQuery,
  onSearchChange,
  totalCount,
  filteredCount,
  tempUnit,
  onToggleTempUnit,
}) {
  return (
    <div className="w-full bg-[#111316] border-y border-white/10 px-6 py-4 sticky top-[57px] z-30 backdrop-blur-md">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
        {/* Category Filters (Interactive Segmented Buttons) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0 scrollbar-none">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                category === cat.id
                  ? 'bg-white/15 text-white font-semibold shadow-sm border border-white/20'
                  : 'text-white/60 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search, Sort, and Unit Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1 sm:w-56 min-w-[160px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Filter locations..."
              className="w-full pl-8 pr-7 py-1.5 text-xs bg-black/40 border border-white/15 rounded text-white placeholder:text-white/30 focus:outline-none focus:border-[#ffcc00] focus:ring-1 focus:ring-[#ffcc00]/50"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-white cursor-pointer"
                aria-label="Clear search"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Sort Filter Selector */}
          <div className="flex items-center gap-1.5 bg-black/40 border border-white/15 rounded px-2.5 py-1">
            <SlidersHorizontal className="w-3 h-3 text-[#ffcc00] shrink-0" />
            <label htmlFor="sort-criterion" className="text-[11px] text-white/40 uppercase tracking-wider font-mono-telemetry sr-only">
              Sort by
            </label>
            <select
              id="sort-criterion"
              value={criterion}
              onChange={(e) => onSelectCriterion(e.target.value)}
              className="bg-transparent text-xs text-white/90 focus:outline-none cursor-pointer pr-1"
            >
              <option value="elevation" className="bg-[#111316] text-white">Elevation Delta</option>
              <option value="temperature-swing" className="bg-[#111316] text-white">Temp Extreme Swing</option>
              <option value="latitude" className="bg-[#111316] text-white">Latitude (Equator to Pole)</option>
              <option value="gravity-ratio" className="bg-[#111316] text-white">Gravity Contrast</option>
              <option value="name" className="bg-[#111316] text-white">Title Alphabetical</option>
            </select>
          </div>

          {/* Sort Direction Toggle Button */}
          <button
            onClick={onToggleDirection}
            className="p-1.5 text-xs bg-black/40 border border-white/15 rounded text-white/70 hover:text-white hover:border-white/30 transition-colors cursor-pointer"
            title={`Direction: ${direction === 'asc' ? 'Ascending' : 'Descending'}`}
            aria-label={`Toggle sort direction. Currently ${direction === 'asc' ? 'Ascending' : 'Descending'}`}
          >
            <ArrowUpDown className={`w-3.5 h-3.5 transition-transform ${direction === 'asc' ? 'rotate-180' : ''}`} />
          </button>

          {/* Temp Unit Toggle */}
          <button
            onClick={onToggleTempUnit}
            className="px-2 py-1 text-xs font-mono-telemetry bg-black/40 border border-white/15 rounded text-white/70 hover:text-[#ffcc00] hover:border-[#ffcc00]/40 transition-colors cursor-pointer"
            title="Toggle temperature unit"
          >
            °{tempUnit}
          </button>

          {/* Quiet Unboxed Counter */}
          <div className="text-[11px] font-mono-telemetry text-white/50 pl-1 whitespace-nowrap">
            Showing <span className="text-white font-medium">{filteredCount}</span> of {totalCount}
          </div>
        </div>
      </div>
    </div>
  );
}
