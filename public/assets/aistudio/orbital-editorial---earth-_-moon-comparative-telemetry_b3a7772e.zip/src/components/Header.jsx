import React from 'react';
import { ArrowLeftRight, Volume2, VolumeX, Sparkles } from 'lucide-react';

export function Header({
  syncScroll,
  onToggleSyncScroll,
  soundEnabled,
  onToggleSound,
  onJumpToTop,
  activeCount,
}) {
  const handleSmoothScroll = (e, targetId) => {
    e.preventDefault();
    const el = document.getElementById(targetId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0c0e11]/90 backdrop-blur-md border-b border-white/10 px-6 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={onJumpToTop}
          className="text-left group cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-[#ffcc00] flex items-baseline"
          aria-label="Orbital Editorial - Back to top"
        >
          <span className="font-editorial text-xl font-bold tracking-tight text-white group-hover:text-[#ffcc00] transition-colors whitespace-nowrap shrink-0">
            Orbital Editorial
          </span>
          <span className="hidden sm:inline-block text-white/40 text-[10px] tracking-widest font-mono-telemetry uppercase ml-2.5">
            EARTH // MOON
          </span>
        </button>

        {/* Zone 2: Clean single-line text navigation links with smooth scrolling */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-white/70">
          <a
            href="#dashboard"
            onClick={(e) => handleSmoothScroll(e, 'dashboard')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Comparative Matrix ({activeCount})
          </a>
          <a
            href="#radar"
            onClick={(e) => handleSmoothScroll(e, 'radar')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Celestial Radar
          </a>
          <a
            href="#physics"
            onClick={(e) => handleSmoothScroll(e, 'physics')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5"
          >
            <span>Astrophysics Reference</span>
            <span className="text-[10px] font-mono-telemetry text-[#ffcc00] bg-[#ffcc00]/10 px-1.5 py-0.2 rounded">INFO</span>
          </a>
        </nav>

        {/* Zone 3: Primary actions with sound & sync scroll */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Subtle audio synthesizer toggle */}
          <button
            onClick={onToggleSound}
            className={`p-1.5 rounded border transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-[#ffcc00]/15 text-[#ffcc00] border-[#ffcc00]/40'
                : 'bg-white/5 text-white/40 border-white/10 hover:text-white hover:bg-white/10'
            }`}
            title={`Telemetry Audio: ${soundEnabled ? 'ON' : 'OFF'}`}
            aria-label={`Toggle sound effects. Currently ${soundEnabled ? 'enabled' : 'disabled'}`}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Sync Scroll Toggle */}
          <button
            onClick={onToggleSyncScroll}
            className={`px-3.5 py-1.5 text-xs font-mono-telemetry font-medium rounded border transition-all flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer ${
              syncScroll
                ? 'bg-[#ffcc00]/15 text-[#ffcc00] border-[#ffcc00]/50 shadow-[0_0_12px_rgba(255,204,0,0.2)]'
                : 'bg-white/5 text-white/70 border-white/15 hover:bg-white/10 hover:text-white'
            }`}
            aria-pressed={syncScroll}
            aria-label={`Toggle Synchronized Scrolling. Currently ${syncScroll ? 'enabled' : 'disabled'}`}
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            <span>Sync Scroll: {syncScroll ? 'ON' : 'OFF'}</span>
          </button>
        </div>
      </div>
    </header>
  );
}
