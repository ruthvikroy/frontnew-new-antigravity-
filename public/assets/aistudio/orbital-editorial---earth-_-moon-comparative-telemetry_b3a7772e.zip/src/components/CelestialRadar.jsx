import React, { useEffect, useRef, useState } from 'react';

export function CelestialRadar({ focusedPair, onSelectPair, allPairs }) {
  const earthCanvasRef = useRef(null);
  const moonCanvasRef = useRef(null);
  const animationFrameRef = useRef(null);
  const rotationAngleRef = useRef(0);
  const [autoRotate, setAutoRotate] = useState(true);
  const [isDraggingEarth, setIsDraggingEarth] = useState(false);
  const [isDraggingMoon, setIsDraggingMoon] = useState(false);
  const lastMouseXRef = useRef(0);

  useEffect(() => {
    let isMounted = true;

    const renderSpheres = () => {
      if (autoRotate && !isDraggingEarth && !isDraggingMoon) {
        rotationAngleRef.current += 0.003;
      }

      // Draw Earth Canvas
      const earthCanvas = earthCanvasRef.current;
      if (earthCanvas) {
        const ctx = earthCanvas.getContext('2d');
        if (ctx) {
          const width = earthCanvas.width;
          const height = earthCanvas.height;
          const cx = width / 2;
          const cy = height / 2;
          const radius = width * 0.38;

          ctx.clearRect(0, 0, width, height);

          // Atmosphere subtle glow
          const grad = ctx.createRadialGradient(cx, cy, radius * 0.7, cx, cy, radius * 1.15);
          grad.addColorStop(0, 'rgba(0, 229, 255, 0.08)');
          grad.addColorStop(0.8, 'rgba(0, 87, 255, 0.12)');
          grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(cx, cy, radius * 1.15, 0, Math.PI * 2);
          ctx.fill();

          // Globe outline
          ctx.strokeStyle = 'rgba(0, 229, 255, 0.4)';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(cx, cy, radius, 0, Math.PI * 2);
          ctx.stroke();

          // Latitude parallels
          ctx.strokeStyle = 'rgba(0, 229, 255, 0.12)';
          ctx.lineWidth = 0.8;
          [-60, -30, 0, 30, 60].forEach((lat) => {
            const y = cy - (radius * Math.sin((lat * Math.PI) / 180));
            const rLat = radius * Math.cos((lat * Math.PI) / 180);
            ctx.beginPath();
            ctx.ellipse(cx, y, rLat, rLat * 0.28, 0, 0, Math.PI * 2);
            ctx.stroke();
          });

          // Longitude meridians rotating
          for (let lon = 0; lon < 360; lon += 45) {
            const currentLonRad = ((lon * Math.PI) / 180) + rotationAngleRef.current;
            const xOffset = Math.sin(currentLonRad) * radius;
            const isVisible = Math.cos(currentLonRad) > 0;
            if (isVisible) {
              ctx.strokeStyle = 'rgba(0, 229, 255, 0.15)';
              ctx.beginPath();
              ctx.ellipse(cx, cy, Math.abs(xOffset), radius, 0, 0, Math.PI * 2);
              ctx.stroke();
            }
          }

          // Render all terrestrial hotspots
          if (allPairs) {
            allPairs.forEach((pair) => {
              const isCurrent = pair.id === focusedPair.id;
              const targetLat = pair.earth.latitude;
              const targetLon = pair.earth.longitude;
              const latRad = (targetLat * Math.PI) / 180;
              const lonRad = (targetLon * Math.PI) / 180 + rotationAngleRef.current;

              if (Math.cos(lonRad) > -0.2) {
                const targetX = cx + Math.sin(lonRad) * radius * Math.cos(latRad);
                const targetY = cy - Math.sin(latRad) * radius;

                if (isCurrent) {
                  const pulse = (Math.sin(Date.now() / 200) + 1) * 3 + 4;
                  ctx.strokeStyle = '#00e5ff';
                  ctx.lineWidth = 1.5;
                  ctx.beginPath();
                  ctx.arc(targetX, targetY, pulse, 0, Math.PI * 2);
                  ctx.stroke();

                  ctx.fillStyle = '#00e5ff';
                  ctx.beginPath();
                  ctx.arc(targetX, targetY, 3, 0, Math.PI * 2);
                  ctx.fill();

                  // Crosshair ticks
                  ctx.beginPath();
                  ctx.moveTo(targetX - 9, targetY);
                  ctx.lineTo(targetX + 9, targetY);
                  ctx.moveTo(targetX, targetY - 9);
                  ctx.lineTo(targetX, targetY + 9);
                  ctx.stroke();
                } else {
                  ctx.fillStyle = 'rgba(0, 229, 255, 0.4)';
                  ctx.beginPath();
                  ctx.arc(targetX, targetY, 2, 0, Math.PI * 2);
                  ctx.fill();
                }
              }
            });
          }
        }
      }

      // Draw Moon Canvas
      const moonCanvas = moonCanvasRef.current;
      if (moonCanvas) {
        const ctx = moonCanvas.getContext('2d');
        if (ctx) {
          const width = moonCanvas.width;
          const height = moonCanvas.height;
          const cx = width / 2;
          const cy = height / 2;
          const radius = width * 0.38;

          ctx.clearRect(0, 0, width, height);

          // Subtle lunar aura
          const grad = ctx.createRadialGradient(cx, cy, radius * 0.7, cx, cy, radius * 1.15);
          grad.addColorStop(0, 'rgba(255, 204, 0, 0.05)');
          grad.addColorStop(0.8, 'rgba(255, 204, 0, 0.10)');
          grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(cx, cy, radius * 1.15, 0, Math.PI * 2);
          ctx.fill();

          // Globe outline
          ctx.strokeStyle = 'rgba(255, 204, 0, 0.4)';
          ctx.lineWidth = 1.2;
          ctx.beginPath();
          ctx.arc(cx, cy, radius, 0, Math.PI * 2);
          ctx.stroke();

          // Lunar Parallels
          ctx.strokeStyle = 'rgba(255, 204, 0, 0.12)';
          ctx.lineWidth = 0.8;
          [-60, -30, 0, 30, 60].forEach((lat) => {
            const y = cy - (radius * Math.sin((lat * Math.PI) / 180));
            const rLat = radius * Math.cos((lat * Math.PI) / 180);
            ctx.beginPath();
            ctx.ellipse(cx, y, rLat, rLat * 0.28, 0, 0, Math.PI * 2);
            ctx.stroke();
          });

          // Lunar Meridians
          const lunarRotation = rotationAngleRef.current * 0.2;
          for (let lon = 0; lon < 360; lon += 45) {
            const currentLonRad = ((lon * Math.PI) / 180) + lunarRotation;
            const xOffset = Math.sin(currentLonRad) * radius;
            const isVisible = Math.cos(currentLonRad) > 0;
            if (isVisible) {
              ctx.strokeStyle = 'rgba(255, 204, 0, 0.15)';
              ctx.beginPath();
              ctx.ellipse(cx, cy, Math.abs(xOffset), radius, 0, 0, Math.PI * 2);
              ctx.stroke();
            }
          }

          // Render all lunar hotspots
          if (allPairs) {
            allPairs.forEach((pair) => {
              const isCurrent = pair.id === focusedPair.id;
              const targetLat = pair.moon.latitude;
              const targetLon = pair.moon.longitude;
              const latRad = (targetLat * Math.PI) / 180;
              const lonRad = (targetLon * Math.PI) / 180 + lunarRotation;

              if (Math.cos(lonRad) > -0.2) {
                const targetX = cx + Math.sin(lonRad) * radius * Math.cos(latRad);
                const targetY = cy - Math.sin(latRad) * radius;

                if (isCurrent) {
                  const pulse = (Math.sin(Date.now() / 200) + 1) * 3 + 4;
                  ctx.strokeStyle = '#ffcc00';
                  ctx.lineWidth = 1.5;
                  ctx.beginPath();
                  ctx.arc(targetX, targetY, pulse, 0, Math.PI * 2);
                  ctx.stroke();

                  ctx.fillStyle = '#ffcc00';
                  ctx.beginPath();
                  ctx.arc(targetX, targetY, 3, 0, Math.PI * 2);
                  ctx.fill();

                  // Crosshair ticks
                  ctx.beginPath();
                  ctx.moveTo(targetX - 9, targetY);
                  ctx.lineTo(targetX + 9, targetY);
                  ctx.moveTo(targetX, targetY - 9);
                  ctx.lineTo(targetX, targetY + 9);
                  ctx.stroke();
                } else {
                  ctx.fillStyle = 'rgba(255, 204, 0, 0.4)';
                  ctx.beginPath();
                  ctx.arc(targetX, targetY, 2, 0, Math.PI * 2);
                  ctx.fill();
                }
              }
            });
          }
        }
      }

      if (isMounted) {
        animationFrameRef.current = requestAnimationFrame(renderSpheres);
      }
    };

    renderSpheres();

    return () => {
      isMounted = false;
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [focusedPair, allPairs, autoRotate, isDraggingEarth, isDraggingMoon]);

  // Drag handlers for manual interactive sphere rotation
  const handleMouseDown = (e, isEarth) => {
    lastMouseXRef.current = e.clientX;
    if (isEarth) setIsDraggingEarth(true);
    else setIsDraggingMoon(true);
  };

  const handleMouseMove = (e) => {
    if (!isDraggingEarth && !isDraggingMoon) return;
    const deltaX = e.clientX - lastMouseXRef.current;
    lastMouseXRef.current = e.clientX;
    rotationAngleRef.current += deltaX * 0.01;
  };

  const handleMouseUp = () => {
    setIsDraggingEarth(false);
    setIsDraggingMoon(false);
  };

  return (
    <section
      id="radar"
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      className="w-full border-b border-white/10 bg-[#0f1115]/80 py-8 px-6"
    >
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-white/5">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-telemetry text-[#ffcc00] uppercase tracking-wider mb-1">
              <span>Celestial Telemetry Vector Reticle</span>
              <span>·</span>
              <span>Interactive Dual Projection</span>
            </div>
            <h2 className="font-editorial text-2xl md:text-3xl font-bold text-white tracking-tight">
              {focusedPair.title}
            </h2>
            <p className="text-white/60 text-sm mt-1 max-w-2xl">
              {focusedPair.thematicParallels}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={() => setAutoRotate((prev) => !prev)}
              className={`px-3 py-1.5 text-xs font-mono-telemetry rounded border transition-colors cursor-pointer ${
                autoRotate
                  ? 'bg-white/15 text-white border-white/30'
                  : 'bg-black/40 text-white/50 border-white/10 hover:text-white'
              }`}
            >
              Orbit: {autoRotate ? 'AUTO' : 'MANUAL DRAG'}
            </button>

            <div className="flex items-center gap-6 font-mono-telemetry text-xs bg-black/40 px-4 py-2 rounded border border-white/10">
              <div>
                <div className="text-white/40 text-[10px] uppercase tracking-widest">Earth Vector</div>
                <div className="text-[#00e5ff] font-medium">{focusedPair.earth.coordinatesFormatted}</div>
              </div>
              <div className="w-px h-6 bg-white/15" />
              <div>
                <div className="text-white/40 text-[10px] uppercase tracking-widest">Moon Vector</div>
                <div className="text-[#ffcc00] font-medium">{focusedPair.moon.coordinatesFormatted}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Dual Orthographic Visualizer Spheres with interactive drag */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
          {/* Earth Telemetry Sphere */}
          <div className="flex items-center gap-6 bg-[#121418] border border-white/10 p-5 rounded-lg relative overflow-hidden group">
            <div
              className="relative w-36 h-36 shrink-0 cursor-grab active:cursor-grabbing"
              onMouseDown={(e) => handleMouseDown(e, true)}
              title="Click & drag to rotate Earth sphere"
            >
              <canvas
                ref={earthCanvasRef}
                width={144}
                height={144}
                className="w-full h-full block"
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] font-mono-telemetry tracking-widest text-[#00e5ff] uppercase mb-1 flex items-center justify-between">
                <span>TERRESTRIAL // {focusedPair.earth.designation}</span>
                <span className="text-white/30 text-[9px]">DRAG TO ROTATE</span>
              </div>
              <h3 className="text-base font-semibold text-white truncate">
                {focusedPair.earth.name}
              </h3>
              <div className="text-xs text-white/50 mb-3 truncate">
                {focusedPair.earth.region}
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono-telemetry">
                <div className="bg-black/30 p-2 rounded border border-white/5">
                  <span className="text-white/40 block text-[10px]">Elevation</span>
                  <span className="text-white font-medium">
                    {focusedPair.earth.metrics.elevationMeters > 0 ? '+' : ''}
                    {focusedPair.earth.metrics.elevationMeters.toLocaleString()} m
                  </span>
                </div>
                <div className="bg-black/30 p-2 rounded border border-white/5">
                  <span className="text-white/40 block text-[10px]">Temp Range</span>
                  <span className="text-[#00e5ff] font-medium">
                    {focusedPair.earth.metrics.tempMinCelsius}°C to {focusedPair.earth.metrics.tempMaxCelsius}°C
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Moon Telemetry Sphere */}
          <div className="flex items-center gap-6 bg-[#121418] border border-white/10 p-5 rounded-lg relative overflow-hidden group">
            <div
              className="relative w-36 h-36 shrink-0 cursor-grab active:cursor-grabbing"
              onMouseDown={(e) => handleMouseDown(e, false)}
              title="Click & drag to rotate Moon sphere"
            >
              <canvas
                ref={moonCanvasRef}
                width={144}
                height={144}
                className="w-full h-full block"
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] font-mono-telemetry tracking-widest text-[#ffcc00] uppercase mb-1 flex items-center justify-between">
                <span>SELENOLOGICAL // {focusedPair.moon.designation}</span>
                <span className="text-white/30 text-[9px]">DRAG TO ROTATE</span>
              </div>
              <h3 className="text-base font-semibold text-white truncate">
                {focusedPair.moon.name}
              </h3>
              <div className="text-xs text-white/50 mb-3 truncate">
                {focusedPair.moon.region}
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono-telemetry">
                <div className="bg-black/30 p-2 rounded border border-white/5">
                  <span className="text-white/40 block text-[10px]">Elevation Datum</span>
                  <span className="text-white font-medium">
                    {focusedPair.moon.metrics.elevationMeters > 0 ? '+' : ''}
                    {focusedPair.moon.metrics.elevationMeters.toLocaleString()} m
                  </span>
                </div>
                <div className="bg-black/30 p-2 rounded border border-white/5">
                  <span className="text-white/40 block text-[10px]">Temp Range</span>
                  <span className="text-[#ffcc00] font-medium">
                    {focusedPair.moon.metrics.tempMinCelsius}°C to {focusedPair.moon.metrics.tempMaxCelsius}°C
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
