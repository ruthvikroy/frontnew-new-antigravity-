import React, { useRef, useEffect } from 'react';
import { LocationCard } from './LocationCard.jsx';
import { ArrowLeftRight, Layers, Sliders, ChevronDown, ChevronUp } from 'lucide-react';

export function SideBySideDashboard({
  pairs,
  tempUnit,
  syncScroll,
  focusedPairId,
  onFocusPair,
  onOpenDetails,
  onResetFilters,
  onPlayClick,
}) {
  const earthColRef = useRef(null);
  const moonColRef = useRef(null);
  const isSyncingRef = useRef(false);

  // Synchronized scrolling logic for dual column mode
  useEffect(() => {
    if (!syncScroll) return;

    const earthCol = earthColRef.current;
    const moonCol = moonColRef.current;
    if (!earthCol || !moonCol) return;

    const handleEarthScroll = () => {
      if (isSyncingRef.current) return;
      isSyncingRef.current = true;
      moonCol.scrollTop = earthCol.scrollTop;
      requestAnimationFrame(() => {
        isSyncingRef.current = false;
      });
    };

    const handleMoonScroll = () => {
      if (isSyncingRef.current) return;
      isSyncingRef.current = true;
      earthCol.scrollTop = moonCol.scrollTop;
      requestAnimationFrame(() => {
        isSyncingRef.current = false;
      });
    };

    earthCol.addEventListener('scroll', handleEarthScroll, { passive: true });
    moonCol.addEventListener('scroll', handleMoonScroll, { passive: true });

    return () => {
      earthCol.removeEventListener('scroll', handleEarthScroll);
      moonCol.removeEventListener('scroll', handleMoonScroll);
    };
  }, [syncScroll]);

  // Scroll intersection observer to sync focused vector on scroll
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.4) {
            const pairId = entry.target.getAttribute('data-pair-id');
            const matched = pairs.find((p) => p.id === pairId);
            if (matched) {
              onFocusPair(matched);
            }
          }
        });
      },
      {
        rootMargin: '-10% 0px -40% 0px',
        threshold: [0.4],
      }
    );

    const elements = document.querySelectorAll('[data-pair-container="true"]');
    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, [pairs, onFocusPair]);

  // Smooth scroll to next or previous pair
  const scrollToPair = (index) => {
    const elements = document.querySelectorAll('[data-pair-container="true"]');
    if (elements[index]) {
      elements[index].scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  if (pairs.length === 0) {
    return (
      <div className="w-full py-24 px-6 text-center">
        <div className="max-w-md mx-auto bg-[#14161a] border border-white/10 rounded-lg p-8">
          <Layers className="w-10 h-10 text-white/30 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-2 font-editorial">No Analog Pairs Found</h3>
          <p className="text-xs text-white/50 mb-6">
            No locations matched your filter or search query. Adjust the filters to explore comparative telemetry.
          </p>
          <button
            onClick={onResetFilters}
            className="px-4 py-2 text-xs font-mono-telemetry bg-white/10 hover:bg-white/20 text-white rounded transition-colors cursor-pointer"
          >
            Reset All Filters
          </button>
        </div>
      </div>
    );
  }

  return (
    <section id="dashboard" className="w-full max-w-7xl mx-auto px-6 py-10 relative">
      {/* Column Headers */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-6 pb-4 border-b border-white/10">
        <div className="lg:col-span-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00e5ff]" />
            <h3 className="font-editorial text-xl font-bold text-white tracking-tight">
              Terrestrial Stations (Earth)
            </h3>
          </div>
          <span className="text-xs font-mono-telemetry text-white/40">
            Datum: Mean Sea Level
          </span>
        </div>

        <div className="hidden lg:flex lg:col-span-2 items-center justify-center">
          <div className="text-[10px] font-mono-telemetry tracking-widest text-[#ffcc00] uppercase text-center">
            SIDE-BY-SIDE ANALOGS
          </div>
        </div>

        <div className="lg:col-span-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#ffcc00]" />
            <h3 className="font-editorial text-xl font-bold text-white tracking-tight">
              Selenological Sites (Moon)
            </h3>
          </div>
          <span className="text-xs font-mono-telemetry text-white/40">
            Datum: 1,737.4 km Sphere
          </span>
        </div>
      </div>

      {/* Paired Location Stream with Scroll Animations */}
      <div className="space-y-8">
        {pairs.map((pair, index) => {
          const isFocused = pair.id === focusedPairId;
          const elevDelta = Math.abs(pair.earth.metrics.elevationMeters - pair.moon.metrics.elevationMeters);
          const tempDelta = Math.abs(
            Math.abs(pair.earth.metrics.tempMaxCelsius - pair.earth.metrics.tempMinCelsius) -
            Math.abs(pair.moon.metrics.tempMaxCelsius - pair.moon.metrics.tempMinCelsius)
          );

          return (
            <div
              key={pair.id}
              data-pair-container="true"
              data-pair-id={pair.id}
              className={`relative rounded-xl transition-all duration-500 p-2 sm:p-4 border ${
                isFocused
                  ? 'bg-white/[0.02] border-white/20 shadow-[0_4px_24px_rgba(0,0,0,0.5)]'
                  : 'border-transparent hover:border-white/10'
              }`}
            >
              {/* Pair Thematic Index Kicker */}
              <div className="flex items-center justify-between px-2 mb-3">
                <div className="flex items-center gap-3">
                  <span className="font-mono-telemetry text-xs text-[#ffcc00] font-semibold">
                    {(index + 1).toString().padStart(2, '0')}.
                  </span>
                  <span className="text-xs font-medium text-white/90 uppercase tracking-wider font-mono-telemetry">
                    {pair.title}
                  </span>
                  <span className="text-white/30 text-xs hidden sm:inline">·</span>
                  <span className="text-xs text-white/50 hidden sm:inline">{pair.categoryLabel}</span>
                </div>

                <div className="flex items-center gap-3">
                  {/* Quick smooth scroll step controls */}
                  <div className="hidden sm:flex items-center gap-1">
                    {index > 0 && (
                      <button
                        onClick={() => scrollToPair(index - 1)}
                        className="p-1 text-white/40 hover:text-white rounded hover:bg-white/5 transition-colors cursor-pointer"
                        title="Scroll to previous location"
                      >
                        <ChevronUp className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {index < pairs.length - 1 && (
                      <button
                        onClick={() => scrollToPair(index + 1)}
                        className="p-1 text-white/40 hover:text-white rounded hover:bg-white/5 transition-colors cursor-pointer"
                        title="Scroll to next location"
                      >
                        <ChevronDown className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <button
                    onClick={() => onOpenDetails(pair)}
                    className="text-xs font-mono-telemetry text-[#ffcc00]/90 hover:text-[#ffcc00] flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Sliders className="w-3 h-3" />
                    <span>Compare Metrics</span>
                  </button>
                </div>
              </div>

              {/* Side-by-Side Dual Column Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                {/* Earth Column (Left) */}
                <div className="lg:col-span-5 h-full">
                  <LocationCard
                    location={pair.earth}
                    type="earth"
                    tempUnit={tempUnit}
                    isHovered={isFocused}
                    onFocus={() => onFocusPair(pair)}
                    onOpenDetails={() => onOpenDetails(pair)}
                    onPlayClick={onPlayClick}
                  />
                </div>

                {/* Central Comparative Connector Spine */}
                <div className="lg:col-span-2 flex flex-col items-center justify-center py-4 lg:py-0">
                  <div className="w-full flex lg:flex-col items-center justify-center gap-3 bg-black/40 border border-white/10 rounded-lg p-3 backdrop-blur-sm">
                    <div className="text-center">
                      <span className="text-[10px] text-white/40 font-mono-telemetry block uppercase">
                        Elevation Delta
                      </span>
                      <span className="text-xs font-mono-telemetry font-semibold text-white">
                        Δ {elevDelta.toLocaleString()} m
                      </span>
                    </div>

                    <div className="hidden lg:block w-full h-px bg-white/10" />

                    <div className="text-center">
                      <span className="text-[10px] text-white/40 font-mono-telemetry block uppercase">
                        Thermal Variance
                      </span>
                      <span className="text-xs font-mono-telemetry font-semibold text-[#ffcc00]">
                        Δ {tempDelta.toFixed(0)}°C swing
                      </span>
                    </div>

                    <button
                      onClick={() => onOpenDetails(pair)}
                      className="mt-1 px-2.5 py-1 text-[11px] font-mono-telemetry text-white/70 hover:text-white bg-white/5 hover:bg-white/15 rounded border border-white/10 transition-colors flex items-center gap-1 cursor-pointer"
                      title="Inspect side-by-side metric differences"
                    >
                      <ArrowLeftRight className="w-3 h-3" />
                      <span>Diff</span>
                    </button>
                  </div>
                </div>

                {/* Moon Column (Right) */}
                <div className="lg:col-span-5 h-full">
                  <LocationCard
                    location={pair.moon}
                    type="moon"
                    tempUnit={tempUnit}
                    isHovered={isFocused}
                    onFocus={() => onFocusPair(pair)}
                    onOpenDetails={() => onOpenDetails(pair)}
                    onPlayClick={onPlayClick}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
