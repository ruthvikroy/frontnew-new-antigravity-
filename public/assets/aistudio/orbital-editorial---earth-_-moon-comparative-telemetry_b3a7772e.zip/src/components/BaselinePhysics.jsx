import React, { useState, useEffect } from 'react';
import {
  Scale,
  Zap,
  Wind,
  Compass,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Info,
  Atom,
  Flame,
  ShieldAlert,
  Orbit,
  Calculator,
} from 'lucide-react';
import { calculateLunarWeight, calculateLunarJumpHeight } from '../utils/comparator.js';

export function BaselinePhysics() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('constants');

  // Interactive Live Calculator State
  const [calcWeight, setCalcWeight] = useState(75);
  const [calcJump, setCalcJump] = useState(40);
  const [customMassPower, setCustomMassPower] = useState(24); // 10^24
  const [customMassCoeff, setCustomMassCoeff] = useState(5.97);
  const [customRadiusKm, setCustomRadiusKm] = useState(6378);

  // Automatically expand if navigated directly to #physics
  useEffect(() => {
    const checkHash = () => {
      if (window.location.hash === '#physics') {
        setIsOpen(true);
      }
    };
    checkHash();
    window.addEventListener('hashchange', checkHash);
    return () => window.removeEventListener('hashchange', checkHash);
  }, []);

  // Fundamental physical constants
  const comparisons = [
    {
      parameter: 'Mass',
      earth: '5.972 × 10^24 kg',
      moon: '7.342 × 10^22 kg',
      contrast: 'Earth is 81.3× more massive',
      icon: Scale,
    },
    {
      parameter: 'Equatorial Radius',
      earth: '6,378.1 km',
      moon: '1,737.4 km',
      contrast: 'Moon is 27.2% the width of Earth',
      icon: Compass,
    },
    {
      parameter: 'Surface Gravity',
      earth: '9.807 m/s² (1.00 g)',
      moon: '1.622 m/s² (0.165 g)',
      contrast: 'Moon gravity is ~1/6th terrestrial',
      icon: Zap,
    },
    {
      parameter: 'Escape Velocity',
      earth: '11.186 km/s (40,270 km/h)',
      moon: '2.380 km/s (8,568 km/h)',
      contrast: 'Lunar escape requires 21.3% the delta-v',
      icon: Orbit,
    },
    {
      parameter: 'Atmosphere Composition',
      earth: '78% N₂, 21% O₂, 1% Ar',
      moon: 'Surface boundary exosphere (He, Ne, H₂)',
      contrast: 'Total lunar atmosphere mass < 10 metric tons',
      icon: Wind,
    },
    {
      parameter: 'Scale Height (H = kT/mg)',
      earth: '8.5 km (exponential barometric decay)',
      moon: 'Ballistic exosphere (H → ∞, collisions negligible)',
      contrast: 'Gas molecules enter free ballistic sub-orbital arcs',
      icon: Atom,
    },
    {
      parameter: 'Magnetic Field Protection',
      earth: 'Global geodynamo (~30–60 µT)',
      moon: 'No global dynamo; localized crustal magnetic swirls',
      contrast: 'Earth magnetosphere deflects 99.5% of solar wind',
      icon: Sparkles,
    },
    {
      parameter: 'Annual Cosmic Radiation Flux',
      earth: '2.4 mSv/year (sea level)',
      moon: '380–420 mSv/year (unshielded surface)',
      contrast: 'Lunar surface receives ~160× terrestrial radiation dose',
      icon: ShieldAlert,
    },
  ];

  // Astrophysics Formula References
  const formulas = [
    {
      title: 'Newtonian Gravitational Acceleration',
      formula: 'g = G · M / R²',
      explanation:
        'Governs the attractive force per unit mass. With Earth mass M_E = 5.972×10²⁴ kg and radius R_E = 6,371 km, g_E ≈ 9.81 m/s². The Moon, having only 1.2% Earth’s mass and 27% its radius, yields g_M = 1.62 m/s² (0.165 g).',
    },
    {
      title: 'Escape Velocity & Kinetic Threshold',
      formula: 'v_e = √(2GM / R)',
      explanation:
        'The parabolic trajectory velocity needed to overcome a celestial body’s gravitational potential well without further propulsion. Earth requires 11.19 km/s (requiring multi-stage rocketry), whereas lunar launch from the surface requires only 2.38 km/s.',
    },
    {
      title: 'Thermal Radiative Equilibrium (Stefan-Boltzmann)',
      formula: 'T_eq = [ (1 - A) · L_☉ / (16 · π · σ · d²) ]^(1/4)',
      explanation:
        'With solar constant S ≈ 1361 W/m² and lunar albedo A ≈ 0.12, the sunlit lunar regolith reaches 395 K (+122°C), while shadowed craters plunge to 27 K (-246°C). On Earth, greenhouse gas re-radiation and atmospheric convection moderate global mean temperature to 288 K (+15°C).',
    },
    {
      title: 'Jeans Atmospheric Escape Mechanism',
      formula: 'v_th = √(3 · k_B · T / m)',
      explanation:
        'Explains why the Moon cannot retain an atmosphere: when thermal Maxwell-Boltzmann molecular velocity v_th exceeds approximately one-sixth of escape velocity (v_th > v_e / 6), gas molecules boil off into space over geological timescales. Water vapor and nitrogen escape within hours on the lunar day-side.',
    },
  ];

  // Calculate live escape velocity for custom parameters
  const G = 6.6743e-11;
  const massKg = customMassCoeff * Math.pow(10, customMassPower);
  const radiusM = customRadiusKm * 1000;
  const customEscapeKms = radiusM > 0 ? (Math.sqrt((2 * G * massKg) / radiusM) / 1000).toFixed(2) : 0;
  const customGravity = radiusM > 0 ? ((G * massKg) / Math.pow(radiusM, 2)).toFixed(2) : 0;

  return (
    <section id="physics" className="w-full border-t border-white/10 bg-[#0d0f12] py-8 px-6 transition-all duration-300">
      <div className="max-w-7xl mx-auto">
        {/* Additional Info Trigger Button Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs font-mono-telemetry uppercase text-[#ffcc00] tracking-wider mb-1 flex items-center gap-1.5">
              <span>Astrophysics Reference Data</span>
              <span>·</span>
              <span className="text-white/40">Theoretical & Observational Physics</span>
            </div>
            <h2 className="font-editorial text-xl sm:text-2xl font-bold text-white tracking-tight">
              Planetary Baseline Invariants & Astrophysical Laws
            </h2>
            <p className="text-xs text-white/50 mt-0.5">
              Formulas, comparative invariants, and live physics simulation between Earth and Moon.
            </p>
          </div>

          <button
            onClick={() => setIsOpen((prev) => !prev)}
            aria-expanded={isOpen}
            aria-controls="physics-details"
            className={`px-4 py-2.5 text-xs font-mono-telemetry font-medium rounded border transition-all flex items-center justify-center gap-2.5 cursor-pointer whitespace-nowrap shrink-0 ${
              isOpen
                ? 'bg-[#ffcc00]/15 text-[#ffcc00] border-[#ffcc00]/50 shadow-[0_0_12px_rgba(255,204,0,0.15)]'
                : 'bg-white/5 text-white/80 border-white/15 hover:bg-white/10 hover:text-white hover:border-white/30'
            }`}
          >
            <Info className="w-3.5 h-3.5 text-[#ffcc00]" />
            <span>Additional Info: {isOpen ? 'Hide Astrophysics Reference' : 'Show Astrophysics Reference'}</span>
            {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Collapsible Enclosed Table & Reference Content */}
        {isOpen && (
          <div id="physics-details" className="mt-8 pt-6 border-t border-white/10 animate-in fade-in duration-300 space-y-6">
            {/* Sub-tab Navigation */}
            <div className="flex items-center gap-2 border-b border-white/10 pb-3 overflow-x-auto scrollbar-none">
              <button
                onClick={() => setActiveTab('constants')}
                className={`px-3 py-1.5 text-xs font-mono-telemetry rounded transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'constants'
                    ? 'bg-white/15 text-white font-medium border border-white/20'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                01. Invariants Table
              </button>
              <button
                onClick={() => setActiveTab('formulas')}
                className={`px-3 py-1.5 text-xs font-mono-telemetry rounded transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'formulas'
                    ? 'bg-white/15 text-white font-medium border border-white/20'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                02. Governing Astrophysics Formulas
              </button>
              <button
                onClick={() => setActiveTab('calculator')}
                className={`px-3 py-1.5 text-xs font-mono-telemetry rounded transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'calculator'
                    ? 'bg-[#ffcc00]/20 text-[#ffcc00] font-medium border border-[#ffcc00]/40'
                    : 'text-[#ffcc00]/70 hover:text-[#ffcc00]'
                }`}
              >
                <Calculator className="w-3 h-3" />
                <span>03. Live Physics Calculator</span>
              </button>
            </div>

            {/* Tab 1: Invariants Table */}
            {activeTab === 'constants' && (
              <div className="space-y-4">
                <div className="text-xs sm:text-sm text-white/60 max-w-xl">
                  Empirical boundary metrics measured by NASA Apollo, LROC, and terrestrial observatories:
                </div>

                <div className="overflow-x-auto rounded-lg border border-white/10 bg-[#111316]">
                  <table className="w-full text-left border-collapse font-mono-telemetry text-xs">
                    <thead>
                      <tr className="border-b border-white/15 text-white/50 text-[11px] uppercase tracking-wider bg-white/[0.02]">
                        <th className="py-3 px-4 font-normal">Physical Parameter</th>
                        <th className="py-3 px-4 font-normal text-[#00e5ff]">Earth (Terrestrial)</th>
                        <th className="py-3 px-4 font-normal text-[#ffcc00]">Moon (Selenological)</th>
                        <th className="py-3 px-4 font-normal text-white/70">Comparative Contrast</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {comparisons.map((row) => {
                        const Icon = row.icon;
                        return (
                          <tr key={row.parameter} className="hover:bg-white/[0.03] transition-colors">
                            <td className="py-3 px-4 text-white font-medium flex items-center gap-2">
                              <Icon className="w-3.5 h-3.5 text-white/40" />
                              <span>{row.parameter}</span>
                            </td>
                            <td className="py-3 px-4 text-[#00e5ff] font-medium">{row.earth}</td>
                            <td className="py-3 px-4 text-[#ffcc00] font-medium">{row.moon}</td>
                            <td className="py-3 px-4 text-white/70">{row.contrast}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Tab 2: Governing Astrophysics Formulas */}
            {activeTab === 'formulas' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {formulas.map((item, idx) => (
                  <div key={idx} className="bg-[#121418] border border-white/10 rounded-lg p-5 flex flex-col justify-between">
                    <div>
                      <div className="text-[10px] font-mono-telemetry text-[#ffcc00] uppercase tracking-wider mb-1">
                        Astrophysics Principle #{idx + 1}
                      </div>
                      <h4 className="font-editorial text-lg font-bold text-white mb-2">{item.title}</h4>
                      <div className="my-3 px-3 py-2 bg-black/60 rounded border border-white/10 font-mono-telemetry text-sm text-[#00e5ff]">
                        {item.formula}
                      </div>
                      <p className="text-xs text-white/70 leading-relaxed font-sans">{item.explanation}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 3: Interactive Live Physics Calculator */}
            {activeTab === 'calculator' && (
              <div className="bg-[#121418] border border-white/10 rounded-lg p-6 space-y-6">
                <div>
                  <h3 className="font-editorial text-xl font-bold text-white mb-1">
                    Comparative Kinematics & Escape Velocity Simulator
                  </h3>
                  <p className="text-xs text-white/60">
                    Calculate biomechanical performance and planetary escape parameters in real-time.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-white/10">
                  {/* Left: Biomechanical Jump & Felt Weight */}
                  <div className="space-y-4 bg-black/40 p-4 rounded-lg border border-white/5">
                    <div className="text-xs font-mono-telemetry text-[#ffcc00] uppercase tracking-wider">
                      Biomechanical Gravity Simulation
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] text-white/50 block font-mono-telemetry uppercase mb-1">
                          Body Weight (kg)
                        </label>
                        <input
                          type="number"
                          min="10"
                          max="300"
                          value={calcWeight}
                          onChange={(e) => setCalcWeight(Math.max(1, Number(e.target.value) || 0))}
                          className="w-full px-3 py-1.5 bg-black border border-white/20 rounded text-white text-xs font-mono-telemetry focus:outline-none focus:border-[#ffcc00]"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-white/50 block font-mono-telemetry uppercase mb-1">
                          Earth Jump Height (cm)
                        </label>
                        <input
                          type="number"
                          min="5"
                          max="150"
                          value={calcJump}
                          onChange={(e) => setCalcJump(Math.max(1, Number(e.target.value) || 0))}
                          className="w-full px-3 py-1.5 bg-black border border-white/20 rounded text-white text-xs font-mono-telemetry focus:outline-none focus:border-[#ffcc00]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <div className="bg-white/5 p-3 rounded">
                        <span className="text-[10px] text-white/40 block font-mono-telemetry uppercase">
                          Earth (1.00 g)
                        </span>
                        <div className="text-sm font-bold text-white font-mono-telemetry mt-1">{calcWeight} kg felt</div>
                        <div className="text-xs text-[#00e5ff] font-mono-telemetry mt-0.5">{calcJump} cm jump</div>
                      </div>

                      <div className="bg-[#ffcc00]/10 border border-[#ffcc00]/20 p-3 rounded">
                        <span className="text-[10px] text-[#ffcc00] block font-mono-telemetry uppercase">
                          Moon (0.165 g)
                        </span>
                        <div className="text-sm font-bold text-white font-mono-telemetry mt-1">
                          {calculateLunarWeight(calcWeight)} kg felt
                        </div>
                        <div className="text-xs text-[#ffcc00] font-mono-telemetry mt-0.5">
                          {calculateLunarJumpHeight(calcJump)} cm jump ({((calcJump * 9.81) / 1.62 / 100).toFixed(2)} m)
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right: Escape Velocity Calculator */}
                  <div className="space-y-4 bg-black/40 p-4 rounded-lg border border-white/5">
                    <div className="text-xs font-mono-telemetry text-[#00e5ff] uppercase tracking-wider">
                      Newtonian Escape Velocity v_e = √(2GM/R)
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] text-white/50 block font-mono-telemetry uppercase mb-1">
                          Body Mass (10^{customMassPower} kg)
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          value={customMassCoeff}
                          onChange={(e) => setCustomMassCoeff(Number(e.target.value) || 0)}
                          className="w-full px-3 py-1.5 bg-black border border-white/20 rounded text-white text-xs font-mono-telemetry focus:outline-none focus:border-[#00e5ff]"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-white/50 block font-mono-telemetry uppercase mb-1">
                          Radius (km)
                        </label>
                        <input
                          type="number"
                          value={customRadiusKm}
                          onChange={(e) => setCustomRadiusKm(Number(e.target.value) || 0)}
                          className="w-full px-3 py-1.5 bg-black border border-white/20 rounded text-white text-xs font-mono-telemetry focus:outline-none focus:border-[#00e5ff]"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setCustomMassCoeff(5.972);
                          setCustomMassPower(24);
                          setCustomRadiusKm(6371);
                        }}
                        className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded text-[10px] font-mono-telemetry text-white/70 cursor-pointer"
                      >
                        Reset Earth
                      </button>
                      <button
                        onClick={() => {
                          setCustomMassCoeff(7.342);
                          setCustomMassPower(22);
                          setCustomRadiusKm(1737);
                        }}
                        className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded text-[10px] font-mono-telemetry text-white/70 cursor-pointer"
                      >
                        Reset Moon
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <div className="bg-white/5 p-3 rounded">
                        <span className="text-[10px] text-white/40 block font-mono-telemetry uppercase">Surface Gravity</span>
                        <div className="text-base font-bold text-white font-mono-telemetry mt-1">{customGravity} m/s²</div>
                      </div>
                      <div className="bg-[#00e5ff]/10 border border-[#00e5ff]/20 p-3 rounded">
                        <span className="text-[10px] text-[#00e5ff] block font-mono-telemetry uppercase">
                          Escape Velocity
                        </span>
                        <div className="text-base font-bold text-[#00e5ff] font-mono-telemetry mt-1">
                          {customEscapeKms} km/s
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
