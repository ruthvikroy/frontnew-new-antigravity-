import React from 'react';
import { ArrowDown, Radio, Orbit, Activity, Shield, Sparkles } from 'lucide-react';

export function HeroSection({ onScrollToMatrix, onScrollToPhysics }) {
  return (
    <section className="relative w-full border-b border-white/10 bg-gradient-to-b from-[#0c0e11] via-[#111316] to-[#0c0e11] px-6 pt-16 pb-12 overflow-hidden">
      {/* Background Reticle Grid */}
      <div className="absolute inset-0 reticle-grid opacity-30 pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-mono-telemetry text-[#ffcc00] uppercase tracking-wider mb-3">
            <span>Interplanetary Comparative Dossier</span>
            <span>·</span>
            <span>Dual Matrix</span>
          </div>

          <h1 className="font-editorial text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.08] text-balance mb-5">
            Terrestrial vs. Selenological Analogs
          </h1>

          <p className="text-base sm:text-lg text-white/70 leading-relaxed max-w-2xl font-sans mb-8">
            Compare extreme terrain elevations, deep tectonic trenches, cryogenic ice traps, and subterranean lava tubes across Earth and the Moon side-by-side with synchronized telemetry and astrophysics calculations.
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={onScrollToMatrix}
              className="px-5 py-2.5 bg-white text-[#0c0e11] text-xs font-semibold rounded hover:bg-white/90 transition-colors flex items-center gap-2 cursor-pointer shadow-lg"
            >
              <span>Explore Locations</span>
              <ArrowDown className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onScrollToPhysics}
              className="px-5 py-2.5 bg-white/5 border border-white/15 text-white/80 hover:text-white text-xs font-medium rounded hover:bg-white/10 transition-colors cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#ffcc00]" />
              <span>Astrophysics Reference Data</span>
            </button>
          </div>
        </div>

        {/* 4-Column KPI Strip in a full-width row below hero */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-white/10">
          {/* KPI 1: Mean Orbital Distance */}
          <div className="bg-[#14161a] border border-white/10 p-4 rounded-lg hover:border-white/20 transition-colors">
            <div className="flex items-center gap-2 text-[10px] font-mono-telemetry text-white/40 uppercase mb-1">
              <Orbit className="w-3 h-3 text-[#ffcc00]" />
              <span>Mean Orbit Distance</span>
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono-telemetry text-white">
              384,400 <span className="text-xs font-normal text-white/50">km</span>
            </div>
            <div className="text-[11px] font-mono-telemetry text-white/40 mt-1">
              1.282 light-seconds delay
            </div>
          </div>

          {/* KPI 2: Gravity Differential */}
          <div className="bg-[#14161a] border border-white/10 p-4 rounded-lg hover:border-white/20 transition-colors">
            <div className="flex items-center gap-2 text-[10px] font-mono-telemetry text-white/40 uppercase mb-1">
              <Activity className="w-3 h-3 text-[#00e5ff]" />
              <span>Surface Gravity Ratio</span>
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono-telemetry text-white">
              6.06 : 1 <span className="text-xs font-normal text-white/50">Δ</span>
            </div>
            <div className="text-[11px] font-mono-telemetry text-white/40 mt-1">
              9.81 m/s² vs 1.62 m/s²
            </div>
          </div>

          {/* KPI 3: Atmosphere Factor */}
          <div className="bg-[#14161a] border border-white/10 p-4 rounded-lg hover:border-white/20 transition-colors">
            <div className="flex items-center gap-2 text-[10px] font-mono-telemetry text-white/40 uppercase mb-1">
              <Shield className="w-3 h-3 text-emerald-400" />
              <span>Atmosphere Delta</span>
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono-telemetry text-white flex items-baseline">
              10<sup className="text-xs text-white/80 font-normal">14</sup> <span className="text-xs font-normal text-white/50 ml-1.5">factor</span>
            </div>
            <div className="text-[11px] font-mono-telemetry text-white/40 mt-1">
              101.3 kPa vs hard vacuum
            </div>
          </div>

          {/* KPI 4: Diurnal Cycle */}
          <div className="bg-[#14161a] border border-white/10 p-4 rounded-lg hover:border-white/20 transition-colors">
            <div className="flex items-center gap-2 text-[10px] font-mono-telemetry text-white/40 uppercase mb-1">
              <Radio className="w-3 h-3 text-purple-400" />
              <span>Day/Night Period</span>
            </div>
            <div className="text-xl sm:text-2xl font-bold font-mono-telemetry text-white">
              24h <span className="text-xs font-normal text-white/50">//</span> 708h
            </div>
            <div className="text-[11px] font-mono-telemetry text-white/40 mt-1">
              1 terrestrial day vs 29.5 days
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
